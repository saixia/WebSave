// ============================================================
// Highlighter System
// ============================================================

import type { Highlight, HighlightColor, HighlightSettings, ShortcutSettings } from '../shared/types';
import { DEFAULT_HIGHLIGHT_SETTINGS, DEFAULT_SHORTCUT_SETTINGS } from '../shared/types';
import { nanoid, getUrlHash, debounce } from '../shared/utils';
import { TextAnchorSystem } from './text-anchor';
import { HighlightToolbar } from './toolbar';
import type { PointerAnchor, ToolbarAnchor } from './toolbar-position';
import { withHighlightColor } from './highlight-actions';
import { isEditableSelectionTarget, shouldOpenForModifierSelection } from './selection-trigger';
import { PageNoteOverlay } from './note-overlay';

const STORAGE_PREFIX = 'web-snapshot:highlights:';

export class Highlighter {
  private textAnchorSystem: TextAnchorSystem;
  private toolbar: HighlightToolbar;
  private noteOverlay: PageNoteOverlay;
  private highlights: Map<string, Highlight> = new Map();
  private currentPageUrl: string;
  private syncDebounced: () => void;
  private shortcutSettings: ShortcutSettings;
  private highlightSettings: HighlightSettings;
  private initialized = false;
  private readonly instanceId = nanoid();
  private readonly handleMouseUp = (event: MouseEvent) => this.onMouseUp(event);
  private readonly handleMouseDown = (event: MouseEvent) => this.onMouseDown(event);
  private readonly handleMouseOver = (event: MouseEvent) => this.onMouseOver(event);
  private readonly handleMouseOut = (event: MouseEvent) => this.onMouseOut(event);

  constructor(
    textAnchorSystem: TextAnchorSystem,
    shortcutSettings: ShortcutSettings = DEFAULT_SHORTCUT_SETTINGS,
    highlightSettings: HighlightSettings = DEFAULT_HIGHLIGHT_SETTINGS,
  ) {
    this.textAnchorSystem = textAnchorSystem;
    document.documentElement.dataset.webSnapshotHighlighterOwner = this.instanceId;
    this.toolbar = new HighlightToolbar(this);
    this.noteOverlay = new PageNoteOverlay();
    this.currentPageUrl = window.location.href;
    this.shortcutSettings = shortcutSettings;
    this.highlightSettings = highlightSettings;
    this.syncDebounced = debounce(() => this.syncToStorage(), 2000);
    this.setupListeners();
    this.initialized = true;
  }

  private setupListeners(): void {
    // Capture modifier mouseup before a stale pre-reload bubble listener can
    // consume the selection and then hide the current toolbar.
    document.addEventListener('mouseup', this.handleMouseUp, true);
    document.addEventListener('mousedown', this.handleMouseDown);
    document.addEventListener('mouseover', this.handleMouseOver);
    document.addEventListener('mouseout', this.handleMouseOut);
  }

  destroy(): void {
    document.removeEventListener('mouseup', this.handleMouseUp, true);
    document.removeEventListener('mousedown', this.handleMouseDown);
    document.removeEventListener('mouseover', this.handleMouseOver);
    document.removeEventListener('mouseout', this.handleMouseOut);
    this.toolbar.destroy();
    this.noteOverlay.destroy();
    if (this.isActiveInstance()) {
      delete document.documentElement.dataset.webSnapshotHighlighterOwner;
    }
    this.initialized = false;
  }

  private onMouseUp(event: MouseEvent): void {
    if (!this.isActiveInstance()) return;

    // Ignore clicks inside the toolbar
    if (this.toolbar.isToolbarEvent(event)) return;

    const highlightMark = (event.target as Element | null)?.closest?.('mark[data-hl-id]');
    if (highlightMark) return;

    if (!shouldOpenForModifierSelection(
      event,
      this.shortcutSettings.selectionModifier,
      this.shortcutSettings.optionSelectionEnabled,
    )) {
      this.toolbar.hide();
      return;
    }

    if (!this.hasCurrentSelection()) {
      this.toolbar.hide();
      return;
    }

    // The configured modifier gesture belongs to the current extension
    // instance. Prevent stale bubble listeners from responding to it again.
    event.stopImmediatePropagation();
    this.showToolbarForCurrentSelection({
      clientX: event.clientX,
      clientY: event.clientY,
    });
  }

  private isActiveInstance(): boolean {
    return document.documentElement.dataset.webSnapshotHighlighterOwner === this.instanceId;
  }

  private hasCurrentSelection(): boolean {
    const selection = window.getSelection();
    return Boolean(selection && !selection.isCollapsed && selection.toString().trim().length > 0);
  }

  showToolbarForCurrentSelection(pointer?: PointerAnchor): boolean {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || selection.toString().trim().length === 0) {
      this.toolbar.hide();
      return false;
    }

    const anchorTarget = selection.anchorNode?.parentElement ?? selection.anchorNode;
    const focusTarget = selection.focusNode?.parentElement ?? selection.focusNode;
    if (isEditableSelectionTarget(anchorTarget) || isEditableSelectionTarget(focusTarget)) {
      this.toolbar.hide();
      return false;
    }

    const range = selection.getRangeAt(0).cloneRange();
    const rect = range.getBoundingClientRect();

    if (rect.width === 0 && rect.height === 0) return false;

    const anchor: ToolbarAnchor = pointer ?? rect;
    this.toolbar.showNewSelection(anchor, range);
    return true;
  }

  updateShortcutSettings(settings: ShortcutSettings): void {
    this.shortcutSettings = settings;
  }

  updateHighlightSettings(settings: HighlightSettings): void {
    this.highlightSettings = settings;
  }

  getDefaultColor(): HighlightColor {
    return this.highlightSettings.defaultColor;
  }

  setPageNotesVisible(visible: boolean): void {
    this.noteOverlay.setVisible(visible);
  }

  getPageNotesVisible(): boolean {
    return this.noteOverlay.getVisible();
  }

  private onMouseDown(event: MouseEvent): void {
    if (!this.isActiveInstance()) return;

    const target = (event.target as Element | null)?.closest?.('mark[data-hl-id]') as HTMLElement | null;
    if (target?.dataset.hlId) {
      const highlight = this.highlights.get(target.dataset.hlId);
      if (highlight) {
        this.toolbar.showExistingHighlight({
          clientX: event.clientX,
          clientY: event.clientY,
        }, highlight);
        event.preventDefault();
      }
    }
  }

  private onMouseOver(event: MouseEvent): void {
    if (!this.isActiveInstance()) return;

    const target = event.target as HTMLElement;
    if (target.tagName === 'MARK' && target.dataset.hlId) {
      const highlight = this.highlights.get(target.dataset.hlId);
      if (highlight?.note) {
        this.toolbar.showNoteBubble({
          clientX: event.clientX,
          clientY: event.clientY,
        }, highlight);
      }
    }
  }

  private onMouseOut(event: MouseEvent): void {
    if (!this.isActiveInstance()) return;

    const target = event.target as HTMLElement;
    if (target.tagName === 'MARK' && target.dataset.hlId) {
      this.toolbar.hideNoteBubble();
    }
  }

  createHighlight(range: Range, color: HighlightColor, note?: string): Highlight | null {
    const text = range.toString();
    if (!text.trim()) return null;

    const anchor = this.textAnchorSystem.createFromRange(range);
    const id = nanoid();

    const highlight: Highlight = {
      id,
      pageUrl: this.currentPageUrl,
      color,
      text,
      note,
      anchor,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      status: 'valid',
    };

    this.applyMarkTag(range, highlight);
    this.highlights.set(id, highlight);
    this.refreshNoteOverlay();
    this.saveToStorage();
    this.syncDebounced();

    return highlight;
  }

  private applyMarkTag(range: Range, highlight: Highlight): void {
    const mark = document.createElement('mark');
    mark.dataset.hlId = highlight.id;
    mark.dataset.hlColor = highlight.color;
    if (highlight.note?.trim()) mark.setAttribute('data-hl-has-note', 'true');
    mark.style.backgroundColor = this.getColorValue(highlight.color);
    mark.style.borderRadius = '2px';
    mark.style.padding = '0 2px';
    mark.style.cursor = 'pointer';

    try {
      range.surroundContents(mark);
    } catch {
      const fragment = range.extractContents();
      mark.appendChild(fragment);
      range.insertNode(mark);
    }
  }

  deleteHighlight(id: string): void {
    const highlight = this.highlights.get(id);
    if (!highlight) return;

    const marks = document.querySelectorAll<HTMLElement>(`mark[data-hl-id="${id}"]`);
    marks.forEach((mark) => {
      const parent = mark.parentNode;
      if (parent) {
        while (mark.firstChild) {
          parent.insertBefore(mark.firstChild, mark);
        }
        parent.removeChild(mark);
        parent.normalize();
      }
    });

    this.highlights.delete(id);
    this.refreshNoteOverlay();
    this.saveToStorage();
    this.syncDebounced();
    this.toolbar.hide();
  }

  updateNote(id: string, note: string): void {
    const highlight = this.highlights.get(id);
    if (!highlight) return;

    highlight.note = note;
    highlight.updatedAt = Date.now();
    document.querySelectorAll<HTMLElement>(`mark[data-hl-id="${id}"]`).forEach((mark) => {
      if (note.trim()) mark.setAttribute('data-hl-has-note', 'true');
      else mark.removeAttribute('data-hl-has-note');
    });
    this.refreshNoteOverlay();
    this.saveToStorage();
    this.syncDebounced();
  }

  updateColor(id: string, color: HighlightColor): Highlight | null {
    const highlight = this.highlights.get(id);
    if (!highlight) return null;

    const updated = withHighlightColor(highlight, color);
    this.highlights.set(id, updated);
    document.querySelectorAll<HTMLElement>(`mark[data-hl-id="${id}"]`).forEach((mark) => {
      mark.dataset.hlColor = color;
      mark.style.backgroundColor = this.getColorValue(color);
    });
    this.refreshNoteOverlay();
    this.saveToStorage();
    this.syncDebounced();
    return updated;
  }

  restoreHighlights(highlights: Highlight[]): void {
    for (const highlight of highlights) {
      if (highlight.status === 'invalid') continue;

      // Content scripts can be re-injected after an extension reload. Reuse
      // an existing visual mark instead of nesting another mark for the same
      // highlight ID.
      if (document.querySelector(`mark[data-hl-id="${highlight.id}"]`)) {
        document.querySelectorAll<HTMLElement>(`mark[data-hl-id="${highlight.id}"]`).forEach((mark) => {
          if (highlight.note?.trim()) mark.setAttribute('data-hl-has-note', 'true');
          else mark.removeAttribute('data-hl-has-note');
        });
        this.highlights.set(highlight.id, highlight);
        continue;
      }

      const range = this.textAnchorSystem.restoreToRange(highlight.anchor);
      if (range) {
        this.applyMarkTag(range, highlight);
        this.highlights.set(highlight.id, highlight);
      } else {
        highlight.status = 'invalid';
        this.highlights.set(highlight.id, highlight);
      }
    }
    this.refreshNoteOverlay();
  }

  getHighlights(): Highlight[] {
    return Array.from(this.highlights.values());
  }

  private refreshNoteOverlay(): void {
    this.noteOverlay.setHighlights(this.getHighlights());
  }

  private async saveToStorage(): Promise<void> {
    try {
      const urlHash = await getUrlHash(this.currentPageUrl);
      const key = `${STORAGE_PREFIX}${urlHash}`;
      const highlights = Array.from(this.highlights.values());
      await chrome.storage.local.set({ [key]: highlights });
    } catch (e) {
      console.error('Failed to save highlights:', e);
    }
  }

  private async syncToStorage(): Promise<void> {
    await this.saveToStorage();
    // Send message to background to trigger cloud sync (SYNC_HIGHLIGHTS)
    chrome.runtime.sendMessage({ type: 'SYNC_HIGHLIGHTS' }).catch(() => {});
  }

  private getColorValue(color: HighlightColor): string {
    const colorMap: Record<HighlightColor, string> = {
      yellow: 'rgba(254, 240, 138, 0.6)',
      green: 'rgba(134, 239, 172, 0.5)',
      blue: 'rgba(147, 197, 253, 0.5)',
      red: 'rgba(252, 165, 165, 0.5)',
    };
    return colorMap[color];
  }
}
