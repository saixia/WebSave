// ============================================================
// WebSave - Content Script
// ============================================================

import type {
  ExtractResult,
  Highlight,
  HighlightSettings,
  ExtensionMessage,
  PageNoteDisplayState,
  SaveFormat,
  ShortcutSettings,
} from '../shared/types';
import { DEFAULT_HIGHLIGHT_SETTINGS, DEFAULT_SHORTCUT_SETTINGS, STORAGE_KEYS } from '../shared/types';
import { createDefaultPageNoteDisplayState } from '../shared/page-note-state';
import { respondToPromise } from '../shared/message-response';
import { Highlighter } from './highlighter';
import { TextAnchorSystem } from './text-anchor';
import {
  addVisibleSnapshotNotes,
  addSnapshotHighlightRule,
  decorateExtensionHighlights,
  finalizeSnapshotMarkdownNotes,
  resolveSnapshotHighlights,
} from './snapshot-dom';

interface WebSaveRuntime {
  extract: (format?: SaveFormat) => Promise<ExtractResult>;
  highlighter: () => Highlighter | null;
  destroy?: () => void;
}

const webSnapshotWindow = window as typeof window & { __webSnapshot?: WebSaveRuntime };
const previousRuntime = webSnapshotWindow.__webSnapshot;
try {
  previousRuntime?.destroy?.();
} catch {
  // The previous extension context may already be invalid after a reload.
}
try {
  previousRuntime?.highlighter?.()?.destroy?.();
} catch {
  // Legacy runtimes did not expose a complete lifecycle API.
}

let highlighter: Highlighter | null = null;
let textAnchorSystem: TextAnchorSystem | null = null;
let highlighterStateReady = false;
let runtimeActive = true;

// --- Extract Content ---

async function extractContent(format: SaveFormat = 'markdown'): Promise<ExtractResult> {
  // Dynamically import Readability and Turndown
  const { Readability } = await import('@mozilla/readability');
  const TurndownService = (await import('turndown')).default;

  // The live highlighter is the source of truth for a just-created highlight.
  // Merging it with storage removes the race between clicking Save and the
  // asynchronous chrome.storage write completing.
  const storedHighlights = await loadHighlights();
  const liveHighlights = highlighter?.getHighlights() || [];
  const highlights = resolveSnapshotHighlights(storedHighlights, liveHighlights, highlighterStateReady);

  // Clone document to avoid modifying the live DOM
  const documentClone = document.cloneNode(true) as Document;

  // Use Readability to extract article
  const reader = new Readability(documentClone);
  const article = reader.parse();

  if (!article) {
    return {
      html: '',
      format,
      title: document.title,
      url: window.location.href,
      author: null,
      publishDate: null,
      images: [],
      highlights,
    };
  }

  // Preserve the exact highlight DOM boundaries produced on the live page.
  // The decorated HTML is shared by local and WebDAV, and by Markdown/HTML.
  const articleContainer = document.createElement('div');
  articleContainer.innerHTML = article.content;
  decorateExtensionHighlights(articleContainer, highlights);
  const articleHtml = articleContainer.innerHTML;

  // Collect image URLs from the decorated extracted content
  const imgElements = articleContainer.querySelectorAll('img');
  const imageUrls: string[] = [];
  imgElements.forEach((img) => {
    if (img.src) imageUrls.push(img.src);
  });

  let content: string;

  if (format === 'html') {
    // Save as standalone HTML — keep Readability output directly
    const htmlContainer = articleContainer.cloneNode(true) as HTMLElement;
    addVisibleSnapshotNotes(htmlContainer);
    const htmlArticle = htmlContainer.innerHTML;
    content = '<!DOCTYPE html>\n<html lang="zh-CN">\n<head>\n'
      + '<meta charset="UTF-8">\n'
      + '<meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
      + '<title>' + (article.title || document.title) + '</title>\n'
      + '<style>\n'
      + '  body{max-width:780px;margin:0 auto;padding:2rem 1.5rem;'
      + 'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC",sans-serif;'
      + 'font-size:16px;line-height:1.8;color:#1a1a1a;background:#fff}\n'
      + '  img{max-width:100%;height:auto}\n'
      + '  pre{background:#f5f5f5;padding:1rem;border-radius:6px;overflow-x:auto;font-size:14px}\n'
      + '  code{background:#f0f0f0;padding:2px 6px;border-radius:3px;font-size:14px}\n'
      + '  pre code{background:none;padding:0}\n'
      + '  blockquote{border-left:3px solid #3b82f6;margin:0;padding:.5rem 1rem;color:#555}\n'
      + '  a{color:#3b82f6}\n'
      + '  mark[data-web-snapshot-highlight="true"]{border-radius:2px;padding:0 2px}\n'
      + '  .web-snapshot-note{display:block;margin:.75rem 0 .5rem;padding:.55rem .75rem;border-left:3px solid #3b82f6;border-radius:0 6px 6px 0;background:#eff6ff;color:#334155;line-height:1.6;white-space:pre-wrap}\n'
      + '  mark[data-web-snapshot-note]{position:relative;cursor:help}\n'
      + '  mark[data-web-snapshot-note]:hover::after{content:attr(data-web-snapshot-note);position:absolute;left:0;bottom:calc(100% + 8px);z-index:10;min-width:180px;max-width:320px;padding:8px 10px;border-radius:8px;background:#0f172a;color:#e2e8f0;box-shadow:0 8px 24px rgba(15,23,42,.28);font-size:13px;line-height:1.5;white-space:normal}\n'
      + '  .src-link{margin-top:2rem;padding-top:1rem;border-top:1px solid #e5e5e5;font-size:14px;color:#888}\n'
      + '</style>\n</head>\n<body>\n'
      + htmlArticle + '\n'
      + '<p class="src-link">原文：<a href="' + window.location.href + '">' + (article.title || document.title) + '</a></p>\n'
      + '</body>\n</html>';
  } else {
    // Convert HTML to Markdown using Turndown
    const turndownService = new TurndownService({
      headingStyle: 'atx',
      codeBlockStyle: 'fenced',
      emDelimiter: '*',
    });

    // Custom rule: collect image URLs
    turndownService.addRule('img', {
      filter: 'img',
      replacement: (_content: string, node: any) => {
        const src = (node as HTMLImageElement).src;
        if (!imageUrls.includes(src)) {
          imageUrls.push(src);
        }
        const alt = (node as HTMLImageElement).alt || '';
        return '![' + alt + '](' + src + ')';
      },
    });

    addSnapshotHighlightRule(turndownService, highlights);

    content = finalizeSnapshotMarkdownNotes(turndownService.turndown(articleHtml), highlights);
  }

  return {
    html: content,
    format,
    title: article.title || document.title,
    url: window.location.href,
    author: article.byline,
    publishDate: article.publishedTime,
    images: imageUrls,
    highlights,
  };
}

// --- Load Highlights directly from storage ---

async function loadHighlights(): Promise<Highlight[]> {
  try {
    const highlights = await chrome.runtime.sendMessage({
      type: 'LOAD_HIGHLIGHTS',
      payload: { pageUrl: window.location.href },
    });
    return Array.isArray(highlights) ? highlights : [];
  } catch {
    return [];
  }
}

async function loadPageNoteDisplayState(): Promise<PageNoteDisplayState> {
  try {
    const state = await chrome.runtime.sendMessage({
      type: 'LOAD_PAGE_NOTE_VISIBILITY',
      payload: { pageUrl: window.location.href },
    });
    if (
      state?.pageUrl === window.location.href
      && typeof state.visible === 'boolean'
      && Number.isFinite(state.updatedAt)
    ) {
      return state as PageNoteDisplayState;
    }
  } catch {
    // Local defaults keep notes usable while background or WebDAV is unavailable.
  }
  return createDefaultPageNoteDisplayState(window.location.href);
}

// --- Initialize Highlighter ---

async function initHighlighter() {
  const stored = await chrome.storage.local.get([
    STORAGE_KEYS.SHORTCUT_SETTINGS,
    STORAGE_KEYS.HIGHLIGHT_SETTINGS,
  ]);
  if (!runtimeActive) return;

  const shortcutSettings: ShortcutSettings = {
    ...DEFAULT_SHORTCUT_SETTINGS,
    ...(stored[STORAGE_KEYS.SHORTCUT_SETTINGS] as Partial<ShortcutSettings> | undefined),
  };
  const highlightSettings: HighlightSettings = {
    ...DEFAULT_HIGHLIGHT_SETTINGS,
    ...(stored[STORAGE_KEYS.HIGHLIGHT_SETTINGS] as Partial<HighlightSettings> | undefined),
  };
  textAnchorSystem = new TextAnchorSystem();
  const nextHighlighter = new Highlighter(textAnchorSystem, shortcutSettings, highlightSettings);
  highlighter = nextHighlighter;

  // Load and restore highlights
  const [highlights, noteDisplay] = await Promise.all([
    loadHighlights(),
    loadPageNoteDisplayState(),
  ]);
  if (!runtimeActive) {
    nextHighlighter.destroy();
    if (highlighter === nextHighlighter) highlighter = null;
    return;
  }
  if (highlights.length > 0) {
    nextHighlighter.restoreHighlights(highlights);
  }
  nextHighlighter.setPageNotesVisible(noteDisplay.visible);
  highlighterStateReady = true;
}

// --- Message Listener ---

const handleMessage = (
  message: ExtensionMessage,
  _sender: chrome.runtime.MessageSender,
  sendResponse: (response?: any) => void,
): boolean => {
  switch (message.type) {
    case 'EXTRACT_CONTENT': {
      const fmt: SaveFormat = message.payload?.format || 'markdown';
      respondToPromise(extractContent(fmt), sendResponse);
      return true;
    }

    case 'SHOW_SELECTION_TOOLBAR':
      sendResponse({ shown: highlighter?.showToolbarForCurrentSelection() ?? false });
      return false;

    case 'APPLY_PAGE_NOTE_VISIBILITY': {
      const visible = message.payload?.visible;
      if (typeof visible !== 'boolean') {
        sendResponse({ applied: false });
        return false;
      }
      const previousVisible = highlighter?.getPageNotesVisible() ?? true;
      highlighter?.setPageNotesVisible(visible);
      chrome.runtime.sendMessage({
        type: 'SAVE_PAGE_NOTE_VISIBILITY',
        payload: { pageUrl: window.location.href, visible },
      }).then((response) => {
        if (response?.error) throw new Error(response.error);
        sendResponse({ applied: true, visible });
      }).catch(() => {
        highlighter?.setPageNotesVisible(previousVisible);
        sendResponse({ applied: false, visible: previousVisible });
      });
      return true;
    }

    // LOAD_HIGHLIGHTS is handled by background/index.ts via chrome.runtime.sendMessage.
    // Do NOT add a handler here, or it will create an infinite loop
    // (content script would intercept the message instead of forwarding to background).
    //
    // case 'LOAD_HIGHLIGHTS':
    //   loadHighlights().then(sendResponse);
    //   return true;

    default:
      return false;
  }
};

chrome.runtime.onMessage.addListener(handleMessage);

const handleStorageChanged = (changes: { [key: string]: chrome.storage.StorageChange }, areaName: string) => {
  if (areaName !== 'local') return;

  const shortcutChange = changes[STORAGE_KEYS.SHORTCUT_SETTINGS];
  if (shortcutChange) {
    const next = shortcutChange.newValue as Partial<ShortcutSettings> | undefined;
    highlighter?.updateShortcutSettings({ ...DEFAULT_SHORTCUT_SETTINGS, ...next });
  }

  const highlightChange = changes[STORAGE_KEYS.HIGHLIGHT_SETTINGS];
  if (highlightChange) {
    const next = highlightChange.newValue as Partial<HighlightSettings> | undefined;
    highlighter?.updateHighlightSettings({ ...DEFAULT_HIGHLIGHT_SETTINGS, ...next });
  }

  for (const [key, change] of Object.entries(changes)) {
    if (!key.startsWith(STORAGE_KEYS.PAGE_NOTE_VISIBILITY_PREFIX)) continue;
    const next = change.newValue as PageNoteDisplayState | undefined;
    if (next?.pageUrl === window.location.href && typeof next.visible === 'boolean') {
      highlighter?.setPageNotesVisible(next.visible);
    }
  }
};

chrome.storage.onChanged.addListener(handleStorageChanged);

// --- Initialize on DOM ready ---

const handleDomReady = () => {
  void initHighlighter();
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', handleDomReady);
} else {
  void initHighlighter();
}

// --- Expose global API for debugging ---

function destroyRuntime(): void {
  if (!runtimeActive) return;
  runtimeActive = false;
  document.removeEventListener('DOMContentLoaded', handleDomReady);
  highlighter?.destroy();
  highlighter = null;
  textAnchorSystem = null;
  highlighterStateReady = false;

  try {
    chrome.runtime.onMessage.removeListener(handleMessage);
    chrome.storage.onChanged.removeListener(handleStorageChanged);
  } catch {
    // Removing DOM listeners and the toolbar still matters after extension reload.
  }
}

webSnapshotWindow.__webSnapshot = {
  extract: extractContent,
  highlighter: () => highlighter,
  destroy: destroyRuntime,
};
