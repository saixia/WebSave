import type { Highlight, HighlightColor } from '../shared/types';

export function withHighlightColor(
  highlight: Highlight,
  color: HighlightColor,
  updatedAt: number = Date.now(),
): Highlight {
  return {
    ...highlight,
    color,
    updatedAt,
  };
}
