import type { Highlight, HighlightColor } from '../shared/types';
import { formatVisibleNoteBlock, mergeHighlights } from '../shared/markdown-highlights.ts';

const SNAPSHOT_HIGHLIGHT_COLORS: Record<HighlightColor, string> = {
  yellow: 'rgba(254, 240, 138, 0.6)',
  green: 'rgba(134, 239, 172, 0.5)',
  blue: 'rgba(147, 197, 253, 0.5)',
  red: 'rgba(252, 165, 165, 0.5)',
};

/**
 * Remove only the visual wrappers created by WebSave. The wrapped text
 * and any original child markup remain in place for Readability/Turndown.
 */
export function unwrapExtensionHighlights(root: ParentNode): number {
  const marks = Array.from(root.querySelectorAll<HTMLElement>('mark[data-hl-id]'));
  let unwrapped = 0;

  for (const mark of marks) {
    const parent = mark.parentNode;
    if (!parent) continue;
    while (mark.firstChild) parent.insertBefore(mark.firstChild, mark);
    parent.removeChild(mark);
    parent.normalize();
    unwrapped++;
  }

  return unwrapped;
}

/**
 * Add durable snapshot metadata to the visual marks already present in the
 * cloned page. This keeps the exact DOM selection boundary intact, including
 * links and other inline markup that cannot be found reliably after Turndown.
 */
export function decorateExtensionHighlights(root: ParentNode, highlights: Highlight[]): number {
  const byId = new Map(highlights.map((highlight) => [highlight.id, highlight]));
  const marks = Array.from(root.querySelectorAll<HTMLElement>('mark[data-hl-id]'));
  let decorated = 0;

  for (const mark of marks) {
    const id = mark.dataset.hlId;
    const highlight = id ? byId.get(id) : undefined;
    if (!highlight) continue;

    mark.dataset.webSnapshotHighlight = 'true';
    mark.dataset.webSnapshotColor = highlight.color;
    mark.style.backgroundColor = SNAPSHOT_HIGHLIGHT_COLORS[highlight.color];

    const note = highlight.note?.trim();
    if (note) {
      mark.dataset.webSnapshotNote = note;
      mark.title = note;
    } else {
      delete mark.dataset.webSnapshotNote;
      mark.title = '';
    }
    decorated++;
  }

  return decorated;
}

/** Add visible note callouts for standalone HTML without changing Markdown input. */
export function addVisibleSnapshotNotes(root: ParentNode): number {
  const marks = Array.from(root.querySelectorAll<HTMLElement>('mark[data-web-snapshot-note]'));
  let inserted = 0;

  for (const mark of marks) {
    const note = mark.dataset.webSnapshotNote?.trim();
    const parent = mark.parentNode;
    const ownerDocument = mark.ownerDocument;
    if (!note || !parent || !ownerDocument) continue;

    const callout = ownerDocument.createElement('span');
    callout.className = 'web-snapshot-note';
    callout.setAttribute('role', 'note');

    const label = ownerDocument.createElement('strong');
    label.textContent = '〔注〕';
    callout.append(label, ownerDocument.createTextNode(` ${note}`));
    parent.insertBefore(callout, mark);
    inserted++;
  }

  return inserted;
}

function snapshotNoteToken(highlightId: string): string {
  return `{{WEBSAVE_NOTE:${encodeURIComponent(highlightId)}}}`;
}

/** Render an inline marker plus a stable token that is moved after Turndown. */
export function renderSnapshotHighlightMarkdown(content: string, highlightId?: string): string {
  const marker = ` ==${content.trim()}== `;
  return highlightId ? `${snapshotNoteToken(highlightId)}${marker}` : marker;
}

/** Move note tokens before their complete containing Markdown lines. */
export function finalizeSnapshotMarkdownNotes(markdown: string, highlights: Highlight[]): string {
  let result = markdown;

  for (const highlight of highlights) {
    const note = highlight.note?.trim();
    if (!note) continue;

    const token = snapshotNoteToken(highlight.id);
    const tokenIndex = result.indexOf(token);
    if (tokenIndex === -1) continue;

    let before = result.slice(0, tokenIndex);
    let after = result.slice(tokenIndex + token.length);
    if (before.endsWith(' ') && after.startsWith(' ')) after = after.slice(1);
    after = after.replace(/^(==[^\n]*?==) {2,}/, '$1 ');

    const lineStart = before.lastIndexOf('\n') + 1;
    before = `${before.slice(0, lineStart)}${formatVisibleNoteBlock(note)}\n${before.slice(lineStart)}`;
    result = before + after;
  }

  return result;
}

interface SnapshotTurndownService {
  addRule(
    name: string,
    rule: {
      filter: (node: any) => boolean;
      replacement: (content: string, node: any) => string;
    },
  ): void;
}

/** Install one DOM-aware rule so inline links/styles remain inside the marker. */
export function addSnapshotHighlightRule(
  service: SnapshotTurndownService,
  highlights: Highlight[],
): void {
  const byId = new Map(highlights.map((highlight) => [highlight.id, highlight]));
  service.addRule('web-snapshot-highlight', {
    filter: (node: any) => node.nodeName === 'MARK' && Boolean(node.getAttribute?.('data-hl-id')),
    replacement: (content: string, node: any) => {
      const highlight = byId.get(node.getAttribute('data-hl-id'));
      return renderSnapshotHighlightMarkdown(content, highlight?.note?.trim() ? highlight.id : undefined);
    },
  });
}

/**
 * Once the page highlighter has finished restoring, its in-memory list is the
 * authoritative current state. Before that point, merge it with storage so an
 * early extraction cannot miss highlights that are still being restored.
 */
export function resolveSnapshotHighlights(
  storedHighlights: Highlight[],
  liveHighlights: Highlight[],
  liveStateReady: boolean,
): Highlight[] {
  return liveStateReady ? [...liveHighlights] : mergeHighlights(storedHighlights, liveHighlights);
}
