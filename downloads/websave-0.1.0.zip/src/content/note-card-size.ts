function longestLineDisplayUnits(text: string): number {
  return text.split(/\r?\n/).reduce((longest, line) => {
    const units = Array.from(line).reduce((total, character) => {
      return total + (/^[\u0000-\u007f]$/.test(character) ? 1 : 2);
    }, 0);
    return Math.max(longest, units);
  }, 0);
}

function widthFromContent(
  text: string,
  minWidth: number,
  maxWidth: number,
  compactUnits: number,
): number {
  const displayUnits = longestLineDisplayUnits(text.trim());
  const rawWidth = minWidth + Math.max(0, displayUnits - compactUnits) * 2;
  if (rawWidth === minWidth) return minWidth;
  const gridWidth = Math.ceil(rawWidth / 8) * 8;
  return Math.max(minWidth, Math.min(gridWidth, maxWidth));
}

export function getNoteCardWidth(note: string): number {
  return widthFromContent(note, 320, 480, 48);
}

export function getNoteBubbleWidth(note: string): number {
  return widthFromContent(note, 260, 400, 36);
}
