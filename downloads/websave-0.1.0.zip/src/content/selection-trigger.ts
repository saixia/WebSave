import type { ShortcutModifier } from '../shared/types';

type SelectionTarget = EventTarget & {
  tagName?: string;
  isContentEditable?: boolean;
  closest?: (selector: string) => Element | null;
  parentElement?: Element | null;
};

export function isEditableSelectionTarget(target: EventTarget | null): boolean {
  if (!target || typeof target !== 'object') return false;
  const selectionTarget = target as SelectionTarget;
  const element = (
    selectionTarget.tagName || typeof selectionTarget.closest === 'function'
      ? selectionTarget
      : selectionTarget.parentElement
  ) as SelectionTarget | null;
  if (!element) return false;
  const tagName = element.tagName?.toUpperCase();
  if (tagName === 'INPUT' || tagName === 'TEXTAREA' || tagName === 'SELECT') return true;
  if (element.isContentEditable) return true;
  return typeof element.closest === 'function'
    && element.closest('input, textarea, select, [contenteditable="true"], [contenteditable=""]') !== null;
}

export function shouldOpenForModifierSelection(
  event: Pick<MouseEvent, 'altKey' | 'metaKey' | 'ctrlKey' | 'shiftKey' | 'target'>,
  modifier: ShortcutModifier,
  enabled: boolean,
): boolean {
  if (!enabled || event.shiftKey || isEditableSelectionTarget(event.target)) return false;

  return modifier === 'alt'
    ? event.altKey && !event.metaKey && !event.ctrlKey
    : modifier === 'meta'
      ? event.metaKey && !event.altKey && !event.ctrlKey
      : event.ctrlKey && !event.altKey && !event.metaKey;
}

export function shouldOpenForOptionSelection(
  event: Pick<MouseEvent, 'altKey' | 'metaKey' | 'ctrlKey' | 'shiftKey' | 'target'>,
  enabled: boolean,
): boolean {
  return shouldOpenForModifierSelection(event, 'alt', enabled);
}
