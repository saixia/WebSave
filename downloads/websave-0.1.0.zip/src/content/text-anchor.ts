// ============================================================
// Text Anchor System - XPath-based text position serialization
// ============================================================

import type { TextAnchor } from '../shared/types';

export class TextAnchorSystem {
  /**
   * Create a TextAnchor from a Selection/Range
   */
  createFromRange(range: Range): TextAnchor {
    const startXPath = this.getXPath(range.startContainer);
    const endXPath = this.getXPath(range.endContainer);
    const textContent = range.toString();

    return {
      startXPath,
      startOffset: range.startOffset,
      endXPath,
      endOffset: range.endOffset,
      textContent,
    };
  }

  /**
   * Restore a Range from a TextAnchor
   */
  restoreToRange(anchor: TextAnchor): Range | null {
    try {
      const startNode = this.resolveXPath(anchor.startXPath);
      const endNode = this.resolveXPath(anchor.endXPath);

      if (!startNode || !endNode) return this.findTextRange(anchor.textContent);

      const range = document.createRange();
      range.setStart(startNode, anchor.startOffset);
      range.setEnd(endNode, anchor.endOffset);

      // Validate text content matches
      const actualText = range.toString();
      if (actualText !== anchor.textContent) {
        return this.findTextRange(anchor.textContent);
      }

      return range;
    } catch {
      return this.findTextRange(anchor.textContent);
    }
  }

  private findTextRange(text: string): Range | null {
    if (!text) return null;

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const nodes: Text[] = [];
    let fullText = '';
    let node: Node | null;
    while ((node = walker.nextNode())) {
      nodes.push(node as Text);
      fullText += node.textContent || '';
    }

    const start = fullText.indexOf(text);
    if (start === -1) return null;
    const end = start + text.length;
    let offset = 0;
    let startNode: Text | null = null;
    let endNode: Text | null = null;
    let startOffset = 0;
    let endOffset = 0;

    for (const current of nodes) {
      const length = (current.textContent || '').length;
      if (!startNode && start >= offset && start < offset + length) {
        startNode = current;
        startOffset = start - offset;
      }
      if (end >= offset && end <= offset + length) {
        endNode = current;
        endOffset = end - offset;
        break;
      }
      offset += length;
    }

    if (!startNode || !endNode) return null;
    const range = document.createRange();
    range.setStart(startNode, startOffset);
    range.setEnd(endNode, endOffset);
    return range;
  }

  /**
   * Get XPath for a DOM node
   */
  private getXPath(node: Node): string {
    if (node.nodeType === Node.TEXT_NODE) {
      const parent = node.parentNode;
      if (!parent) return '';

      const siblings = Array.from(parent.childNodes).filter(
        (n) => n.nodeType === Node.TEXT_NODE
      );
      const index = siblings.indexOf(node as Text);
      const parentXPath = this.getElementXPath(parent as Element);
      return `${parentXPath}/text()[${index + 1}]`;
    }

    return this.getElementXPath(node as Element);
  }

  /**
   * Get XPath for an Element node
   */
  private getElementXPath(element: Element): string {
    if (element.id) {
      return `//*[@id="${element.id}"]`;
    }

    const parts: string[] = [];
    let current: Element | null = element;

    while (current && current !== document.body && current !== document.documentElement) {
      let index = 1;
      const parent = current.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(
          (sibling) => sibling.tagName === current!.tagName
        );
        index = siblings.indexOf(current) + 1;
      }

      parts.unshift(`${current.tagName.toLowerCase()}[${index}]`);
      current = current.parentElement;
    }

    if (current === document.body) {
      parts.unshift('body[1]');
    } else if (current === document.documentElement) {
      parts.unshift('html[1]');
    }

    return '/' + parts.join('/');
  }

  /**
   * Resolve an XPath to a DOM node
   */
  private resolveXPath(xpath: string): Node | null {
    try {
      const result = document.evaluate(
        xpath,
        document,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE,
        null
      );
      return result.singleNodeValue;
    } catch {
      return null;
    }
  }
}
