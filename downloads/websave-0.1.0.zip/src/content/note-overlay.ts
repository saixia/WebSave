import type { Highlight, HighlightColor } from '../shared/types';
import { getNoteBubbleWidth } from './note-card-size';
import {
  computeNoteOverlayLayout,
  selectRightEdgeNoteAnchor,
  type NoteOverlayInput,
} from './note-overlay-layout';

const NOTE_OVERLAY_ID = 'web-snapshot-page-note-overlay';
const NOTE_ACCENT_COLORS: Record<HighlightColor, string> = {
  yellow: '#facc15',
  green: '#4ade80',
  blue: '#60a5fa',
  red: '#fb4b55',
};

interface RenderedNote {
  highlight: Highlight;
  badge: HTMLElement;
  card: HTMLElement;
  connector: HTMLElement;
  cardWidth: number;
  cardHeight: number;
}

function estimateCardHeight(note: string): number {
  const lines = note.split(/\r?\n/);
  const visualLines = lines.reduce((sum, line) => sum + Math.max(1, Math.ceil(line.length / 24)), 0);
  return Math.min(220, Math.max(72, 48 + (visualLines * 22)));
}

export class PageNoteOverlay {
  private readonly host: HTMLElement;
  private readonly layer: HTMLElement;
  private readonly status: HTMLElement;
  private readonly rendered = new Map<string, RenderedNote>();
  private highlights: Highlight[] = [];
  private visible = true;
  private contentDirty = true;
  private frameId: number | null = null;
  private readonly resizeObserver: ResizeObserver | null;
  private readonly handleViewportChange = () => this.scheduleLayout();

  constructor() {
    document.getElementById(NOTE_OVERLAY_ID)?.remove();
    this.host = document.createElement('div');
    this.host.id = NOTE_OVERLAY_ID;
    this.host.setAttribute('aria-hidden', 'true');
    this.host.style.position = 'fixed';
    this.host.style.inset = '0';
    this.host.style.zIndex = '2147483644';
    this.host.style.pointerEvents = 'none';

    const shadowRoot = this.host.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = `
      :host {
        --ws-note-bg: rgba(15, 35, 65, .96);
        --ws-note-border: rgba(71, 85, 105, .78);
        --ws-note-text: #f8fafc;
        --ws-note-accent: #fb4b55;
        --ws-note-shadow: 0 14px 34px rgba(15, 23, 42, .28), 0 3px 10px rgba(15, 23, 42, .18);
        all: initial;
      }
      .layer {
        position: fixed;
        inset: 0;
        overflow: hidden;
        pointer-events: none;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", sans-serif;
      }
      .status {
        position: absolute;
        top: 18px;
        right: 24px;
        padding: 7px 13px;
        border: 1px solid rgba(148, 163, 184, .42);
        border-radius: 999px;
        background: rgba(255, 255, 255, .9);
        color: #2563eb;
        box-shadow: 0 4px 14px rgba(15, 23, 42, .08);
        font-size: 13px;
        line-height: 1;
        backdrop-filter: blur(8px);
      }
      .badge {
        position: absolute;
        box-sizing: border-box;
        width: 28px;
        height: 28px;
        display: grid;
        place-items: center;
        border: 2px solid var(--ws-note-accent);
        border-radius: 50%;
        background: #0f294c;
        color: white;
        box-shadow: 0 3px 10px rgba(15, 23, 42, .3);
      }
      .badge::before { content: "▤"; font-size: 13px; line-height: 1; }
      .connector {
        position: absolute;
        height: 1px;
        background: var(--ws-note-accent);
        transform: translateY(-.5px);
        transform-origin: left center;
      }
      .card {
        position: absolute;
        box-sizing: border-box;
        min-width: 260px;
        max-width: min(400px, calc(100vw - 24px));
        padding: 16px 18px;
        border: 1px solid var(--ws-note-border);
        border-radius: 12px;
        background: var(--ws-note-bg);
        color: var(--ws-note-text);
        box-shadow: var(--ws-note-shadow);
        font-size: 14px;
        line-height: 1.55;
        backdrop-filter: blur(12px);
      }
      .card-row { display: flex; align-items: flex-start; gap: 12px; }
      .card-dot {
        flex: 0 0 auto;
        width: 18px;
        height: 18px;
        margin-top: 2px;
        border-radius: 4px;
        background: var(--ws-note-accent);
        box-shadow: 0 0 0 1px rgba(255,255,255,.08) inset;
      }
      .card-copy { min-width: 0; max-height: min(42vh, 320px); overflow: auto; }
      .card-label { margin-right: 8px; color: #e2e8f0; font-weight: 650; }
      .card-text { color: #f8fafc; white-space: pre-wrap; overflow-wrap: anywhere; }
    `;
    this.layer = document.createElement('div');
    this.layer.className = 'layer';
    this.status = document.createElement('div');
    this.status.className = 'status';
    this.status.textContent = '本页备注：显示 · 已按 URL 记住';
    shadowRoot.append(style, this.layer);
    (document.documentElement || document.body).appendChild(this.host);

    window.addEventListener('scroll', this.handleViewportChange, true);
    window.addEventListener('resize', this.handleViewportChange);
    this.resizeObserver = typeof ResizeObserver === 'function'
      ? new ResizeObserver(this.handleViewportChange)
      : null;
    if (document.documentElement) this.resizeObserver?.observe(document.documentElement);
  }

  setVisible(visible: boolean): void {
    if (this.visible === visible) return;
    this.visible = visible;
    this.scheduleLayout();
  }

  getVisible(): boolean {
    return this.visible;
  }

  setHighlights(highlights: Highlight[]): void {
    this.highlights = highlights;
    this.contentDirty = true;
    this.scheduleLayout();
  }

  destroy(): void {
    window.removeEventListener('scroll', this.handleViewportChange, true);
    window.removeEventListener('resize', this.handleViewportChange);
    this.resizeObserver?.disconnect();
    if (this.frameId !== null) window.cancelAnimationFrame(this.frameId);
    this.frameId = null;
    this.rendered.clear();
    this.host.remove();
  }

  private scheduleLayout(): void {
    if (this.frameId !== null) return;
    this.frameId = window.requestAnimationFrame(() => {
      this.frameId = null;
      this.render();
    });
  }

  private rebuildContent(): void {
    this.layer.replaceChildren(this.status);
    this.rendered.clear();

    for (const highlight of this.highlights.filter((item) => item.note?.trim())) {
      const accent = NOTE_ACCENT_COLORS[highlight.color];
      const badge = document.createElement('div');
      badge.className = 'badge';
      badge.style.setProperty('--ws-note-accent', accent);
      const connector = document.createElement('div');
      connector.className = 'connector';
      connector.style.setProperty('--ws-note-accent', accent);
      const card = document.createElement('div');
      card.className = 'card';
      card.style.setProperty('--ws-note-accent', accent);
      const cardWidth = getNoteBubbleWidth(highlight.note || '');
      card.style.width = `${cardWidth}px`;

      const row = document.createElement('div');
      row.className = 'card-row';
      const dot = document.createElement('span');
      dot.className = 'card-dot';
      const copy = document.createElement('div');
      copy.className = 'card-copy';
      const label = document.createElement('span');
      label.className = 'card-label';
      label.textContent = '〔注〕';
      const text = document.createElement('span');
      text.className = 'card-text';
      text.textContent = highlight.note || '';
      copy.append(label, text);
      row.append(dot, copy);
      card.appendChild(row);
      this.layer.append(connector, badge, card);

      const cardHeight = card.getBoundingClientRect().height || estimateCardHeight(highlight.note || '');
      this.rendered.set(highlight.id, {
        highlight,
        badge,
        card,
        connector,
        cardWidth,
        cardHeight,
      });
    }

    this.contentDirty = false;
  }

  private render(): void {
    if (this.contentDirty) this.rebuildContent();
    this.host.style.display = 'block';
    this.status.style.display = this.visible && this.rendered.size > 0 ? 'block' : 'none';

    const marksById = new Map<string, HTMLElement>();
    document.querySelectorAll<HTMLElement>('mark[data-hl-id]').forEach((mark) => {
      if (mark.dataset.hlId) marksById.set(mark.dataset.hlId, mark);
    });

    const inputs: NoteOverlayInput[] = [];
    this.rendered.forEach((elements, id) => {
      elements.badge.style.display = 'none';
      elements.card.style.display = 'none';
      elements.connector.style.display = 'none';

      const mark = marksById.get(id);
      if (!mark) return;
      const rects = Array.from(mark.getClientRects())
        .filter((rect) => rect.width > 0 || rect.height > 0)
        .map((rect) => ({ left: rect.left, top: rect.top, right: rect.right, bottom: rect.bottom }));
      const fallback = mark.getBoundingClientRect();
      const anchor = selectRightEdgeNoteAnchor(rects)
        || { left: fallback.left, top: fallback.top, right: fallback.right, bottom: fallback.bottom };
      if (anchor.right === anchor.left && anchor.bottom === anchor.top) return;

      inputs.push({
        id,
        anchor,
        cardWidth: elements.cardWidth,
        cardHeight: elements.cardHeight,
      });
    });

    computeNoteOverlayLayout(inputs, {
      width: window.innerWidth,
      height: window.innerHeight,
    }).forEach((layout) => {
      const elements = this.rendered.get(layout.id);
      if (!elements) return;
      elements.badge.style.left = `${layout.badgeLeft}px`;
      elements.badge.style.top = `${layout.badgeTop}px`;
      elements.badge.style.display = 'grid';
      elements.card.style.left = `${layout.cardLeft}px`;
      elements.card.style.top = `${layout.cardTop}px`;
      elements.card.style.display = this.visible ? 'block' : 'none';
      elements.connector.style.left = `${layout.connectorLeft}px`;
      elements.connector.style.top = `${layout.connectorTop}px`;
      elements.connector.style.width = `${layout.connectorWidth}px`;
      elements.connector.style.display = this.visible && layout.connectorWidth > 0 ? 'block' : 'none';
    });
  }
}
