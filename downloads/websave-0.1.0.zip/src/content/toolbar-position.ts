export interface PointerAnchor {
  clientX: number;
  clientY: number;
}

export interface RectangleAnchor {
  left: number;
  top: number;
  bottom: number;
  width: number;
  height: number;
}

export type ToolbarAnchor = PointerAnchor | RectangleAnchor;

interface Size {
  width: number;
  height: number;
}

interface Viewport {
  width: number;
  height: number;
}

export function positionToolbarAboveAnchor(
  anchor: ToolbarAnchor,
  size: Size,
  viewport: Viewport,
  gap = 12,
): { left: number; top: number } {
  const margin = 10;
  const isPointer = 'clientX' in anchor;
  const centerX = isPointer ? anchor.clientX : anchor.left + anchor.width / 2;
  const anchorTop = isPointer ? anchor.clientY : anchor.top;
  const anchorBottom = isPointer ? anchor.clientY : anchor.bottom;

  let left = centerX - size.width / 2;
  left = Math.max(margin, Math.min(left, viewport.width - size.width - margin));

  let top = anchorTop - size.height - gap;
  if (top < margin) {
    top = anchorBottom + gap;
  }
  top = Math.max(margin, Math.min(top, viewport.height - size.height - margin));

  return { left, top };
}
