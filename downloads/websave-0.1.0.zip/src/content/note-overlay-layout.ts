export interface NoteOverlayAnchor {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

export interface NoteOverlayInput {
  id: string;
  anchor: NoteOverlayAnchor;
  cardWidth: number;
  cardHeight: number;
}

export interface NoteOverlayLayout {
  id: string;
  badgeLeft: number;
  badgeTop: number;
  cardLeft: number;
  cardTop: number;
  connectorLeft: number;
  connectorTop: number;
  connectorWidth: number;
}

export interface NoteOverlayViewport {
  width: number;
  height: number;
}

const BADGE_SIZE = 28;
const CARD_RIGHT_INSET = 24;
const CARD_TOP_INSET = 16;
const CARD_BOTTOM_INSET = 16;
const CARD_GAP = 12;

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), Math.max(min, max));
}

export function selectRightEdgeNoteAnchor(
  rects: NoteOverlayAnchor[],
): NoteOverlayAnchor | undefined {
  return rects.reduce<NoteOverlayAnchor | undefined>((rightmost, rect) => {
    if (!rightmost || rect.right > rightmost.right) return rect;
    if (rect.right === rightmost.right && rect.top < rightmost.top) return rect;
    return rightmost;
  }, undefined);
}

export function computeNoteOverlayLayout(
  inputs: NoteOverlayInput[],
  viewport: NoteOverlayViewport,
): NoteOverlayLayout[] {
  const visible = inputs
    .filter(({ anchor }) => anchor.bottom > 0 && anchor.top < viewport.height)
    .sort((a, b) => a.anchor.top - b.anchor.top);
  let nextCardTop = CARD_TOP_INSET;

  const layouts = visible.map((input) => {
    const anchorHeight = Math.max(0, input.anchor.bottom - input.anchor.top);
    const badgeLeft = clamp(
      input.anchor.right - (BADGE_SIZE / 2),
      8,
      viewport.width - BADGE_SIZE - 8,
    );
    const badgeTop = clamp(
      input.anchor.top + ((anchorHeight - BADGE_SIZE) / 2),
      8,
      viewport.height - BADGE_SIZE - 8,
    );
    const cardLeft = clamp(
      viewport.width - input.cardWidth - CARD_RIGHT_INSET,
      12,
      viewport.width - input.cardWidth - 12,
    );
    const preferredTop = clamp(
      input.anchor.top,
      CARD_TOP_INSET,
      viewport.height - input.cardHeight - CARD_BOTTOM_INSET,
    );
    const cardTop = Math.max(preferredTop, nextCardTop);
    nextCardTop = cardTop + input.cardHeight + CARD_GAP;
    const connectorLeft = badgeLeft + BADGE_SIZE;

    return {
      id: input.id,
      badgeLeft,
      badgeTop,
      cardLeft,
      cardTop,
      connectorLeft,
      connectorTop: badgeTop + (BADGE_SIZE / 2),
      connectorWidth: Math.max(0, cardLeft - connectorLeft),
    };
  });

  const last = layouts[layouts.length - 1];
  const lastInput = last && visible.find(({ id }) => id === last.id);
  const overflow = last && lastInput
    ? (last.cardTop + lastInput.cardHeight + CARD_BOTTOM_INSET) - viewport.height
    : 0;
  if (overflow > 0 && layouts.length > 0) {
    const availableShift = Math.max(0, layouts[0].cardTop - CARD_TOP_INSET);
    const shift = Math.min(overflow, availableShift);
    layouts.forEach((layout) => { layout.cardTop -= shift; });
  }

  return layouts;
}
