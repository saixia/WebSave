// ============================================================
// Highlight Toolbar - Floating UI for highlight operations
// ============================================================

import type { Highlight, HighlightColor } from '../shared/types';
import type { Highlighter } from './highlighter';
import { getNoteBubbleWidth, getNoteCardWidth } from './note-card-size';
import { positionToolbarAboveAnchor, type ToolbarAnchor } from './toolbar-position';

const PENDING_NOTE_PREVIEW = 'web-snapshot-pending-note';
const PENDING_NOTE_PREVIEW_STYLE_ID = 'web-snapshot-pending-note-style';
const HIGHLIGHT_BUTTON_COLORS: Record<HighlightColor, string> = {
  yellow: '#fef08a',
  green: '#86efac',
  blue: '#93c5fd',
  red: '#fca5a5',
};
const HIGHLIGHT_PREVIEW_COLORS: Record<HighlightColor, string> = {
  yellow: 'rgba(254, 240, 138, 0.6)',
  green: 'rgba(134, 239, 172, 0.5)',
  blue: 'rgba(147, 197, 253, 0.5)',
  red: 'rgba(252, 165, 165, 0.5)',
};

type CustomHighlightRegistry = {
  set(name: string, highlight: unknown): void;
  delete(name: string): boolean;
};

type CustomHighlightConstructor = new (...ranges: Range[]) => unknown;

export class HighlightToolbar {
  private highlighter: Highlighter;
  private shadowRoot: ShadowRoot | null = null;
  private container: HTMLElement | null = null;
  private currentMode: 'pending-selection' | 'existing-highlight' | null = null;
  private currentHighlight: Highlight | null = null;
  private bubbleTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(highlighter: Highlighter) {
    this.highlighter = highlighter;
    this.createContainer();
  }

  private createContainer(): void {
    // An extension reload can leave the previous content script's toolbar in
    // the page. Remove every orphan before attaching the current instance so
    // one text selection can never display both the legacy and current UI.
    document.querySelectorAll('#web-snapshot-toolbar').forEach((orphanedToolbar) => {
      orphanedToolbar.remove();
    });

    this.container = document.createElement('div');
    this.container.id = 'web-snapshot-toolbar';
    this.container.style.cssText = `
      position: fixed;
      z-index: 2147483647;
      display: none;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
      font-size: 14px;
    `;

    this.shadowRoot = this.container.attachShadow({ mode: 'open' });

    document.body.appendChild(this.container);
  }

  destroy(): void {
    if (this.bubbleTimer) {
      clearTimeout(this.bubbleTimer);
      this.bubbleTimer = null;
    }
    this.clearPendingNotePreview();
    this.container?.remove();
    this.container = null;
    this.shadowRoot = null;
    this.currentMode = null;
    this.currentHighlight = null;
  }

  isToolbarEvent(event: MouseEvent): boolean {
    const target = event.target as Node;
    // Check if the event target is inside the toolbar container
    // Using open shadow DOM so we can traverse into it
    if (!this.container) return false;
    
    // Check if the target is the container itself or inside it
    if (target === this.container) return true;
    if (this.container.contains(target)) return true;
    
    // Also check if the target is inside the shadow root
    if (this.shadowRoot && this.shadowRoot.contains(target)) return true;
    
    return false;
  }

  showNewSelection(
    anchor: ToolbarAnchor,
    range: Range,
    note = '',
    editingNote = false,
  ): void {
    if (!this.container || !this.shadowRoot) return;

    if (!editingNote) {
      this.clearPendingNotePreview();
    }

    this.currentMode = 'pending-selection';
    this.currentHighlight = null;
    const defaultColor = this.highlighter.getDefaultColor();

    const wrapper = document.createElement('div');
    wrapper.className = 'highlight-card selection-card';
    wrapper.style.width = `${getNoteCardWidth(note)}px`;

    const header = document.createElement('div');
    header.className = 'highlight-card-header';

    const colorsWrapper = document.createElement('div');
    colorsWrapper.className = 'highlight-card-colors';
    const colors: HighlightColor[] = ['yellow', 'green', 'blue', 'red'];
    let created = false;
    let draftNote = note;
    const createPendingHighlight = (color: HighlightColor, currentNote: string) => {
      if (created) return;
      created = true;
      this.clearPendingNotePreview();
      const highlight = this.highlighter.createHighlight(range, color, currentNote || undefined);
      if (!highlight) {
        this.hide();
        return;
      }
      window.getSelection()?.removeAllRanges();
      this.showExistingHighlight(anchor, highlight);
    };
    colors.forEach((color) => {
      const button = document.createElement('button');
      button.className = 'color-btn';
      button.style.backgroundColor = HIGHLIGHT_BUTTON_COLORS[color];
      button.title = `使用${color}高亮`;
      button.setAttribute('aria-label', button.title);
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        createPendingHighlight(color, draftNote);
      });
      colorsWrapper.appendChild(button);
    });
    header.appendChild(colorsWrapper);

    const actions = document.createElement('div');
    actions.className = 'highlight-card-actions';

    const noteBtn = document.createElement('button');
    noteBtn.className = 'icon-btn';
    noteBtn.textContent = '✏️';
    noteBtn.title = note ? '编辑注释' : '添加注释';
    noteBtn.setAttribute('aria-label', noteBtn.title);
    noteBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      if (editingNote) {
        this.shadowRoot?.querySelector<HTMLTextAreaElement>('.highlight-note-editor textarea')?.focus();
        return;
      }
      this.showNewSelection(anchor, range, note, true);
    });
    actions.appendChild(noteBtn);

    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'icon-btn';
    cancelBtn.textContent = '✕';
    cancelBtn.title = '取消高亮';
    cancelBtn.setAttribute('aria-label', cancelBtn.title);
    cancelBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      window.getSelection()?.removeAllRanges();
      this.hide();
    });
    actions.appendChild(cancelBtn);
    header.appendChild(actions);
    wrapper.appendChild(header);

    let resizeEditor: (() => void) | null = null;
    if (editingNote) {
      const editor = document.createElement('div');
      editor.className = 'highlight-note-editor';

      const textarea = document.createElement('textarea');
      textarea.maxLength = 1000;
      textarea.placeholder = '输入备注…';
      textarea.value = note;
      editor.appendChild(textarea);

      resizeEditor = () => {
        const width = getNoteCardWidth(textarea.value);
        wrapper.style.width = `${width}px`;
        const maxHeight = Math.max(76, Math.min(320, Math.floor(window.innerHeight * 0.42)));
        textarea.style.height = 'auto';
        const contentHeight = Math.max(76, textarea.scrollHeight);
        textarea.style.height = `${Math.min(contentHeight, maxHeight)}px`;
        textarea.style.overflowY = contentHeight > maxHeight ? 'auto' : 'hidden';
        this.positionContainer(wrapper, anchor, { width, height: maxHeight });
      };
      textarea.addEventListener('input', () => {
        draftNote = textarea.value.trim();
        resizeEditor?.();
      });

      const editorActions = document.createElement('div');
      editorActions.className = 'highlight-note-editor-actions';

      const editorCancelBtn = document.createElement('button');
      editorCancelBtn.type = 'button';
      editorCancelBtn.className = 'note-cancel';
      editorCancelBtn.textContent = '取消';
      editorCancelBtn.addEventListener('click', (event) => {
        event.stopPropagation();
        this.clearPendingNotePreview();
        this.showNewSelection(anchor, range);
      });

      const saveBtn = document.createElement('button');
      saveBtn.type = 'button';
      saveBtn.className = 'note-save';
      saveBtn.textContent = '保存';
      const save = () => {
        draftNote = textarea.value.trim();
        createPendingHighlight(defaultColor, draftNote);
      };
      saveBtn.addEventListener('click', (event) => {
        event.stopPropagation();
        save();
      });

      editorActions.append(editorCancelBtn, saveBtn);
      editor.appendChild(editorActions);
      wrapper.appendChild(editor);

      textarea.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
          event.preventDefault();
          this.clearPendingNotePreview();
          this.showNewSelection(anchor, range);
        }
        if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) {
          event.preventDefault();
          save();
        }
      });
    } else {
      const hint = document.createElement('div');
      hint.className = `highlight-note${note ? '' : ' empty'}`;
      hint.textContent = note || '请选择颜色创建高亮，可先添加备注';
      wrapper.appendChild(hint);
    }

    this.render(wrapper, anchor);
    if (editingNote) {
      this.showPendingNotePreview(range, defaultColor);
      setTimeout(() => {
        const editor = this.shadowRoot?.querySelector<HTMLTextAreaElement>('.highlight-note-editor textarea');
        if (editor) {
          resizeEditor?.();
          editor.focus();
        }
      }, 0);
    }
  }

  showExistingHighlight(anchor: ToolbarAnchor, highlight: Highlight, editingNote = false): void {
    if (!this.container || !this.shadowRoot) return;

    this.clearPendingNotePreview();

    this.currentMode = 'existing-highlight';
    this.currentHighlight = highlight;

    const wrapper = document.createElement('div');
    wrapper.className = 'highlight-card';
    wrapper.style.width = `${getNoteCardWidth(highlight.note || '')}px`;

    const header = document.createElement('div');
    header.className = 'highlight-card-header';

    const colorsWrapper = document.createElement('div');
    colorsWrapper.className = 'highlight-card-colors';
    const colors: HighlightColor[] = ['yellow', 'green', 'blue', 'red'];
    colors.forEach((color) => {
      const button = document.createElement('button');
      button.className = `color-btn${highlight.color === color ? ' active' : ''}`;
      button.style.backgroundColor = HIGHLIGHT_BUTTON_COLORS[color];
      button.title = `改为${color}高亮`;
      button.setAttribute('aria-label', button.title);
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        const updated = this.highlighter.updateColor(highlight.id, color);
        if (!updated) return;
        this.currentHighlight = updated;
        this.showExistingHighlight(anchor, updated);
      });
      colorsWrapper.appendChild(button);
    });
    header.appendChild(colorsWrapper);

    const actions = document.createElement('div');
    actions.className = 'highlight-card-actions';

    const noteBtn = document.createElement('button');
    noteBtn.className = 'icon-btn';
    noteBtn.textContent = '✏️';
    noteBtn.title = highlight.note ? '编辑注释' : '添加注释';
    noteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (editingNote) {
        this.shadowRoot?.querySelector<HTMLTextAreaElement>('.highlight-note-editor textarea')?.focus();
        return;
      }
      this.showExistingHighlight(anchor, highlight, true);
    });
    actions.appendChild(noteBtn);

    // Delete button
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'icon-btn';
    deleteBtn.textContent = '🗑️';
    deleteBtn.title = '删除高亮';
    deleteBtn.style.color = '#ef4444';
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      this.highlighter.deleteHighlight(highlight.id);
      this.hide();
    });
    actions.appendChild(deleteBtn);
    header.appendChild(actions);
    wrapper.appendChild(header);

    let resizeEditor: (() => void) | null = null;
    if (editingNote) {
      const editor = document.createElement('div');
      editor.className = 'highlight-note-editor';

      const textarea = document.createElement('textarea');
      textarea.maxLength = 1000;
      textarea.placeholder = '输入备注…';
      textarea.value = highlight.note || '';
      editor.appendChild(textarea);

      resizeEditor = () => {
        const width = getNoteCardWidth(textarea.value);
        wrapper.style.width = `${width}px`;
        const maxHeight = Math.max(76, Math.min(320, Math.floor(window.innerHeight * 0.42)));
        textarea.style.height = 'auto';
        const contentHeight = Math.max(76, textarea.scrollHeight);
        textarea.style.height = `${Math.min(contentHeight, maxHeight)}px`;
        textarea.style.overflowY = contentHeight > maxHeight ? 'auto' : 'hidden';
        this.positionContainer(wrapper, anchor, { width, height: maxHeight });
      };
      textarea.addEventListener('input', resizeEditor);

      const actions = document.createElement('div');
      actions.className = 'highlight-note-editor-actions';

      const cancelBtn = document.createElement('button');
      cancelBtn.type = 'button';
      cancelBtn.className = 'note-cancel';
      cancelBtn.textContent = '取消';
      cancelBtn.addEventListener('click', (event) => {
        event.stopPropagation();
        this.showExistingHighlight(anchor, highlight);
      });

      const saveBtn = document.createElement('button');
      saveBtn.type = 'button';
      saveBtn.className = 'note-save';
      saveBtn.textContent = '保存';
      const save = () => {
        this.highlighter.updateNote(highlight.id, textarea.value.trim());
        this.showExistingHighlight(anchor, highlight);
      };
      saveBtn.addEventListener('click', (event) => {
        event.stopPropagation();
        save();
      });

      actions.append(cancelBtn, saveBtn);
      editor.appendChild(actions);
      wrapper.appendChild(editor);

      textarea.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
          event.preventDefault();
          this.showExistingHighlight(anchor, highlight);
        }
        if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) {
          event.preventDefault();
          save();
        }
      });
    } else {
      const note = document.createElement('div');
      note.className = `highlight-note${highlight.note ? '' : ' empty'}`;
      note.textContent = highlight.note || '暂无备注，点击编辑按钮添加备注';
      wrapper.appendChild(note);
    }

    this.render(wrapper, anchor);
    if (editingNote) {
      setTimeout(() => {
        const editor = this.shadowRoot?.querySelector<HTMLTextAreaElement>('.highlight-note-editor textarea');
        if (editor) {
          resizeEditor?.();
          editor.focus();
        }
      }, 0);
    }
  }

  private render(wrapper: HTMLElement, anchor: ToolbarAnchor): void {
    if (!this.shadowRoot || !this.container) return;

    // Clear previous content
    this.shadowRoot.innerHTML = '';
    const style = document.createElement('style');
    style.textContent = `
      :host { all: initial; }
      .highlight-card {
        background: #1e293b;
        border: 1px solid #334155;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4);
        padding: 8px 12px;
        display: flex;
        align-items: center;
        gap: 8px;
        position: relative;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
        font-size: 14px;
      }
      .color-btn {
        width: 16px; height: 16px; border-radius: 50%;
        border: 2px solid transparent; cursor: pointer; padding: 0;
        transition: transform 150ms ease-out;
      }
      .color-btn:hover { transform: scale(1.2); }
      .color-btn.active { border-color: #f8fafc; box-shadow: 0 0 0 2px #3b82f6; }
      .icon-btn {
        width: 22px; height: 22px; border: none; background: transparent;
        color: #94a3b8; cursor: pointer; border-radius: 4px;
        display: flex; align-items: center; justify-content: center;
        font-size: 14px; padding: 0;
        transition: background 150ms ease-out;
      }
      .icon-btn:hover { background: #334155; color: #f1f5f9; }
      .highlight-card {
        box-sizing: border-box; width: 320px; max-width: calc(100vw - 20px); padding: 12px;
        display: block; color: #f1f5f9;
      }
      .highlight-card-header { display: flex; align-items: center; justify-content: space-between; gap: 18px; }
      .highlight-card-colors, .highlight-card-actions { display: flex; align-items: center; gap: 10px; }
      .highlight-card-actions { gap: 6px; }
      .highlight-note {
        margin-top: 11px; padding-top: 10px; border-top: 1px solid #334155;
        color: #e2e8f0; line-height: 1.55; white-space: pre-wrap; overflow-wrap: anywhere;
        max-height: min(42vh, 320px); overflow-y: auto;
      }
      .highlight-note.empty { color: #64748b; }
      .highlight-note-editor {
        margin-top: 11px; padding-top: 10px; border-top: 1px solid #334155;
      }
      .highlight-note-editor textarea {
        box-sizing: border-box; display: block; width: 100%; min-height: 76px; resize: none;
        padding: 8px; color: #f8fafc; background: #1e293b; border: 1px solid #475569; border-radius: 8px;
        font: inherit; outline: none;
      }
      .highlight-note-editor textarea:focus { border-color: #3b82f6; box-shadow: 0 0 0 2px rgba(59,130,246,.2); }
      .highlight-note-editor-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 10px; }
      .highlight-note-editor button { border: 0; border-radius: 7px; padding: 6px 10px; cursor: pointer; font: inherit; }
      .note-cancel { background: #334155; color: #e2e8f0; }
      .note-save { background: #3b82f6; color: white; }
    `;
    this.shadowRoot.appendChild(style);
    this.shadowRoot.appendChild(wrapper);

    this.positionContainer(wrapper, anchor, { width: 320, height: 120 });
  }

  private positionContainer(
    wrapper: HTMLElement,
    anchor: ToolbarAnchor,
    fallbackSize: { width: number; height: number },
  ): void {
    if (!this.container) return;
    // Measure the rendered card so every state remains centered directly
    // above the pointer without relying on a fixed guessed height.
    this.container.style.display = 'block';
    this.container.style.visibility = 'hidden';
    this.container.style.left = '0px';
    this.container.style.top = '0px';
    const bounds = wrapper.getBoundingClientRect();
    const size = {
      width: bounds.width || fallbackSize.width,
      height: bounds.height || fallbackSize.height,
    };
    const { left, top } = positionToolbarAboveAnchor(
      anchor,
      size,
      { width: window.innerWidth, height: window.innerHeight },
    );
    this.container.style.left = `${left}px`;
    this.container.style.top = `${top}px`;
    this.container.style.visibility = 'visible';
  }

  private showPendingNotePreview(range: Range, color: HighlightColor): void {
    const css = (globalThis as unknown as {
      CSS?: { highlights?: CustomHighlightRegistry };
    }).CSS;
    const HighlightConstructor = (globalThis as unknown as {
      Highlight?: CustomHighlightConstructor;
    }).Highlight;
    const registry = css?.highlights;
    if (!registry || !HighlightConstructor) return;

    let style = document.getElementById(PENDING_NOTE_PREVIEW_STYLE_ID);
    if (!style) {
      style = document.createElement('style');
      style.id = PENDING_NOTE_PREVIEW_STYLE_ID;
      style.textContent = `::highlight(${PENDING_NOTE_PREVIEW}) { background-color: ${HIGHLIGHT_PREVIEW_COLORS[color]}; }`;
      (document.head || document.documentElement).appendChild(style);
    }

    registry.set(PENDING_NOTE_PREVIEW, new HighlightConstructor(range.cloneRange()));
  }

  private clearPendingNotePreview(): void {
    const css = (globalThis as unknown as {
      CSS?: { highlights?: CustomHighlightRegistry };
    }).CSS;
    css?.highlights?.delete(PENDING_NOTE_PREVIEW);
    document.getElementById(PENDING_NOTE_PREVIEW_STYLE_ID)?.remove();
  }

  hide(): void {
    this.clearPendingNotePreview();
    if (this.container) {
      this.container.style.display = 'none';
    }
    this.currentMode = null;
    this.currentHighlight = null;
  }

  showNoteBubble(anchor: ToolbarAnchor, highlight: Highlight): void {
    if (!this.container || !this.shadowRoot || !highlight.note) return;

    // Clear any pending hide
    if (this.bubbleTimer) {
      clearTimeout(this.bubbleTimer);
      this.bubbleTimer = null;
    }

    // Don't show bubble if toolbar is already open for this highlight
    if (this.currentMode === 'existing-highlight' && this.currentHighlight?.id === highlight.id) return;

    const wrapper = document.createElement('div');
    wrapper.className = 'note-bubble';
    const bubbleWidth = getNoteBubbleWidth(highlight.note);
    wrapper.style.width = `${bubbleWidth}px`;

    const noteText = document.createElement('div');
    noteText.className = 'note-text';
    noteText.textContent = highlight.note;
    wrapper.appendChild(noteText);

    const editButton = document.createElement('button');
    editButton.className = 'note-edit-btn';
    editButton.textContent = '✏️ 编辑';
    editButton.addEventListener('click', (e) => {
      e.stopPropagation();
      this.showExistingHighlight(anchor, highlight, true);
    });
    wrapper.appendChild(editButton);

    // Render bubble
    this.shadowRoot.innerHTML = '';
    const style = document.createElement('style');
    style.textContent = `
      :host { all: initial; }
      .note-bubble {
        background: #1e293b;
        border: 1px solid #334155;
        border-radius: 8px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.4);
        padding: 8px 12px;
        box-sizing: border-box;
        max-width: calc(100vw - 20px);
        position: relative;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
        font-size: 13px;
      }
      .note-text {
        color: #f1f5f9;
        line-height: 1.5;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
        max-height: min(42vh, 320px);
        overflow-y: auto;
        margin-bottom: 8px;
      }
      .note-edit-btn {
        font-size: 12px;
        color: #3b82f6;
        background: none;
        border: none;
        cursor: pointer;
        padding: 2px 0;
        display: block;
        text-align: left;
      }
      .note-edit-btn:hover {
        color: #60a5fa;
      }
    `;
    this.shadowRoot.appendChild(style);
    this.shadowRoot.appendChild(wrapper);
    this.positionContainer(wrapper, anchor, { width: bubbleWidth, height: 90 });
  }

  hideNoteBubble(): void {
    this.bubbleTimer = setTimeout(() => {
      // Only hide if we're showing a bubble (not a toolbar)
      if (this.currentMode === null) {
        this.hide();
      }
    }, 200);
  }
}
