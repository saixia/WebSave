import{f as D,e as $,n as U,h as at,a as lt,S as C}from"./utils-UR3DvrLo.js";import{m as ct,f as ht,b as dt,c as ut}from"./message-response-B6pr0Cuh.js";const gt="modulepreload",pt=function(r,t){return new URL(r,t).href},X={},z=function(t,e,n){let o=Promise.resolve();if(e&&e.length>0){const s=document.getElementsByTagName("link"),c=document.querySelector("meta[property=csp-nonce]"),a=(c==null?void 0:c.nonce)||(c==null?void 0:c.getAttribute("nonce"));o=Promise.allSettled(e.map(l=>{if(l=pt(l,n),l in X)return;X[l]=!0;const g=l.endsWith(".css"),w=g?'[rel="stylesheet"]':"";if(!!n)for(let u=s.length-1;u>=0;u--){const m=s[u];if(m.href===l&&(!g||m.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${l}"]${w}`))return;const h=document.createElement("link");if(h.rel=g?"stylesheet":gt,g||(h.as="script"),h.crossOrigin="",h.href=l,a&&h.setAttribute("nonce",a),document.head.appendChild(h),g)return new Promise((u,m)=>{h.addEventListener("load",u),h.addEventListener("error",()=>m(new Error(`Unable to preload CSS for ${l}`)))})}))}function i(s){const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=s,window.dispatchEvent(c),!c.defaultPrevented)throw s}return o.then(s=>{for(const c of s||[])c.status==="rejected"&&i(c.reason);return t().catch(i)})};function mt(r){return r.split(/\r?\n/).reduce((t,e)=>{const n=Array.from(e).reduce((o,i)=>o+(/^[\u0000-\u007f]$/.test(i)?1:2),0);return Math.max(t,n)},0)}function Z(r,t,e,n){const o=mt(r.trim()),i=t+Math.max(0,o-n)*2;if(i===t)return t;const s=Math.ceil(i/8)*8;return Math.max(t,Math.min(s,e))}function H(r){return Z(r,320,480,48)}function J(r){return Z(r,260,400,36)}function ft(r,t,e,n=12){const i="clientX"in r,s=i?r.clientX:r.left+r.width/2,c=i?r.clientY:r.top,a=i?r.clientY:r.bottom;let l=s-t.width/2;l=Math.max(10,Math.min(l,e.width-t.width-10));let g=c-t.height-n;return g<10&&(g=a+n),g=Math.max(10,Math.min(g,e.height-t.height-10)),{left:l,top:g}}const O="web-snapshot-pending-note",L="web-snapshot-pending-note-style",F={yellow:"#fef08a",green:"#86efac",blue:"#93c5fd",red:"#fca5a5"},bt={yellow:"rgba(254, 240, 138, 0.6)",green:"rgba(134, 239, 172, 0.5)",blue:"rgba(147, 197, 253, 0.5)",red:"rgba(252, 165, 165, 0.5)"};class wt{constructor(t){this.shadowRoot=null,this.container=null,this.currentMode=null,this.currentHighlight=null,this.bubbleTimer=null,this.highlighter=t,this.createContainer()}createContainer(){document.querySelectorAll("#web-snapshot-toolbar").forEach(t=>{t.remove()}),this.container=document.createElement("div"),this.container.id="web-snapshot-toolbar",this.container.style.cssText=`
      position: fixed;
      z-index: 2147483647;
      display: none;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
      font-size: 14px;
    `,this.shadowRoot=this.container.attachShadow({mode:"open"}),document.body.appendChild(this.container)}destroy(){var t;this.bubbleTimer&&(clearTimeout(this.bubbleTimer),this.bubbleTimer=null),this.clearPendingNotePreview(),(t=this.container)==null||t.remove(),this.container=null,this.shadowRoot=null,this.currentMode=null,this.currentHighlight=null}isToolbarEvent(t){const e=t.target;return this.container?!!(e===this.container||this.container.contains(e)||this.shadowRoot&&this.shadowRoot.contains(e)):!1}showNewSelection(t,e,n="",o=!1){if(!this.container||!this.shadowRoot)return;o||this.clearPendingNotePreview(),this.currentMode="pending-selection",this.currentHighlight=null;const i=this.highlighter.getDefaultColor(),s=document.createElement("div");s.className="highlight-card selection-card",s.style.width=`${H(n)}px`;const c=document.createElement("div");c.className="highlight-card-header";const a=document.createElement("div");a.className="highlight-card-colors";const l=["yellow","green","blue","red"];let g=!1,w=n;const p=(b,d)=>{var v;if(g)return;g=!0,this.clearPendingNotePreview();const x=this.highlighter.createHighlight(e,b,d||void 0);if(!x){this.hide();return}(v=window.getSelection())==null||v.removeAllRanges(),this.showExistingHighlight(t,x)};l.forEach(b=>{const d=document.createElement("button");d.className="color-btn",d.style.backgroundColor=F[b],d.title=`使用${b}高亮`,d.setAttribute("aria-label",d.title),d.addEventListener("click",x=>{x.stopPropagation(),p(b,w)}),a.appendChild(d)}),c.appendChild(a);const h=document.createElement("div");h.className="highlight-card-actions";const u=document.createElement("button");u.className="icon-btn",u.textContent="✏️",u.title=n?"编辑注释":"添加注释",u.setAttribute("aria-label",u.title),u.addEventListener("click",b=>{var d,x;if(b.stopPropagation(),o){(x=(d=this.shadowRoot)==null?void 0:d.querySelector(".highlight-note-editor textarea"))==null||x.focus();return}this.showNewSelection(t,e,n,!0)}),h.appendChild(u);const m=document.createElement("button");m.className="icon-btn",m.textContent="✕",m.title="取消高亮",m.setAttribute("aria-label",m.title),m.addEventListener("click",b=>{var d;b.stopPropagation(),(d=window.getSelection())==null||d.removeAllRanges(),this.hide()}),h.appendChild(m),c.appendChild(h),s.appendChild(c);let y=null;if(o){const b=document.createElement("div");b.className="highlight-note-editor";const d=document.createElement("textarea");d.maxLength=1e3,d.placeholder="输入备注…",d.value=n,b.appendChild(d),y=()=>{const E=H(d.value);s.style.width=`${E}px`;const M=Math.max(76,Math.min(320,Math.floor(window.innerHeight*.42)));d.style.height="auto";const G=Math.max(76,d.scrollHeight);d.style.height=`${Math.min(G,M)}px`,d.style.overflowY=G>M?"auto":"hidden",this.positionContainer(s,t,{width:E,height:M})},d.addEventListener("input",()=>{w=d.value.trim(),y==null||y()});const x=document.createElement("div");x.className="highlight-note-editor-actions";const v=document.createElement("button");v.type="button",v.className="note-cancel",v.textContent="取消",v.addEventListener("click",E=>{E.stopPropagation(),this.clearPendingNotePreview(),this.showNewSelection(t,e)});const N=document.createElement("button");N.type="button",N.className="note-save",N.textContent="保存";const V=()=>{w=d.value.trim(),p(i,w)};N.addEventListener("click",E=>{E.stopPropagation(),V()}),x.append(v,N),b.appendChild(x),s.appendChild(b),d.addEventListener("keydown",E=>{E.key==="Escape"&&(E.preventDefault(),this.clearPendingNotePreview(),this.showNewSelection(t,e)),E.key==="Enter"&&(E.metaKey||E.ctrlKey)&&(E.preventDefault(),V())})}else{const b=document.createElement("div");b.className=`highlight-note${n?"":" empty"}`,b.textContent=n||"请选择颜色创建高亮，可先添加备注",s.appendChild(b)}this.render(s,t),o&&(this.showPendingNotePreview(e,i),setTimeout(()=>{var d;const b=(d=this.shadowRoot)==null?void 0:d.querySelector(".highlight-note-editor textarea");b&&(y==null||y(),b.focus())},0))}showExistingHighlight(t,e,n=!1){if(!this.container||!this.shadowRoot)return;this.clearPendingNotePreview(),this.currentMode="existing-highlight",this.currentHighlight=e;const o=document.createElement("div");o.className="highlight-card",o.style.width=`${H(e.note||"")}px`;const i=document.createElement("div");i.className="highlight-card-header";const s=document.createElement("div");s.className="highlight-card-colors",["yellow","green","blue","red"].forEach(p=>{const h=document.createElement("button");h.className=`color-btn${e.color===p?" active":""}`,h.style.backgroundColor=F[p],h.title=`改为${p}高亮`,h.setAttribute("aria-label",h.title),h.addEventListener("click",u=>{u.stopPropagation();const m=this.highlighter.updateColor(e.id,p);m&&(this.currentHighlight=m,this.showExistingHighlight(t,m))}),s.appendChild(h)}),i.appendChild(s);const a=document.createElement("div");a.className="highlight-card-actions";const l=document.createElement("button");l.className="icon-btn",l.textContent="✏️",l.title=e.note?"编辑注释":"添加注释",l.addEventListener("click",p=>{var h,u;if(p.stopPropagation(),n){(u=(h=this.shadowRoot)==null?void 0:h.querySelector(".highlight-note-editor textarea"))==null||u.focus();return}this.showExistingHighlight(t,e,!0)}),a.appendChild(l);const g=document.createElement("button");g.className="icon-btn",g.textContent="🗑️",g.title="删除高亮",g.style.color="#ef4444",g.addEventListener("click",p=>{p.stopPropagation(),this.highlighter.deleteHighlight(e.id),this.hide()}),a.appendChild(g),i.appendChild(a),o.appendChild(i);let w=null;if(n){const p=document.createElement("div");p.className="highlight-note-editor";const h=document.createElement("textarea");h.maxLength=1e3,h.placeholder="输入备注…",h.value=e.note||"",p.appendChild(h),w=()=>{const d=H(h.value);o.style.width=`${d}px`;const x=Math.max(76,Math.min(320,Math.floor(window.innerHeight*.42)));h.style.height="auto";const v=Math.max(76,h.scrollHeight);h.style.height=`${Math.min(v,x)}px`,h.style.overflowY=v>x?"auto":"hidden",this.positionContainer(o,t,{width:d,height:x})},h.addEventListener("input",w);const u=document.createElement("div");u.className="highlight-note-editor-actions";const m=document.createElement("button");m.type="button",m.className="note-cancel",m.textContent="取消",m.addEventListener("click",d=>{d.stopPropagation(),this.showExistingHighlight(t,e)});const y=document.createElement("button");y.type="button",y.className="note-save",y.textContent="保存";const b=()=>{this.highlighter.updateNote(e.id,h.value.trim()),this.showExistingHighlight(t,e)};y.addEventListener("click",d=>{d.stopPropagation(),b()}),u.append(m,y),p.appendChild(u),o.appendChild(p),h.addEventListener("keydown",d=>{d.key==="Escape"&&(d.preventDefault(),this.showExistingHighlight(t,e)),d.key==="Enter"&&(d.metaKey||d.ctrlKey)&&(d.preventDefault(),b())})}else{const p=document.createElement("div");p.className=`highlight-note${e.note?"":" empty"}`,p.textContent=e.note||"暂无备注，点击编辑按钮添加备注",o.appendChild(p)}this.render(o,t),n&&setTimeout(()=>{var h;const p=(h=this.shadowRoot)==null?void 0:h.querySelector(".highlight-note-editor textarea");p&&(w==null||w(),p.focus())},0)}render(t,e){if(!this.shadowRoot||!this.container)return;this.shadowRoot.innerHTML="";const n=document.createElement("style");n.textContent=`
      :host { all: initial; }
      .highlight-card {
        background: #1e293b;
        border: 1px solid #334155;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4);
        padding: 8px 12px;
        display: flex;
        align-items: center;
        gap: 8px;
        position: relative;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
        font-size: 14px;
      }
      .color-btn {
        width: 16px; height: 16px; border-radius: 50%;
        border: 2px solid transparent; cursor: pointer; padding: 0;
        transition: transform 150ms ease-out;
      }
      .color-btn:hover { transform: scale(1.2); }
      .color-btn.active { border-color: #f8fafc; box-shadow: 0 0 0 2px #3b82f6; }
      .icon-btn {
        width: 22px; height: 22px; border: none; background: transparent;
        color: #94a3b8; cursor: pointer; border-radius: 4px;
        display: flex; align-items: center; justify-content: center;
        font-size: 14px; padding: 0;
        transition: background 150ms ease-out;
      }
      .icon-btn:hover { background: #334155; color: #f1f5f9; }
      .highlight-card {
        box-sizing: border-box; width: 320px; max-width: calc(100vw - 20px); padding: 12px;
        display: block; color: #f1f5f9;
      }
      .highlight-card-header { display: flex; align-items: center; justify-content: space-between; gap: 18px; }
      .highlight-card-colors, .highlight-card-actions { display: flex; align-items: center; gap: 10px; }
      .highlight-card-actions { gap: 6px; }
      .highlight-note {
        margin-top: 11px; padding-top: 10px; border-top: 1px solid #334155;
        color: #e2e8f0; line-height: 1.55; white-space: pre-wrap; overflow-wrap: anywhere;
        max-height: min(42vh, 320px); overflow-y: auto;
      }
      .highlight-note.empty { color: #64748b; }
      .highlight-note-editor {
        margin-top: 11px; padding-top: 10px; border-top: 1px solid #334155;
      }
      .highlight-note-editor textarea {
        box-sizing: border-box; display: block; width: 100%; min-height: 76px; resize: none;
        padding: 8px; color: #f8fafc; background: #1e293b; border: 1px solid #475569; border-radius: 8px;
        font: inherit; outline: none;
      }
      .highlight-note-editor textarea:focus { border-color: #3b82f6; box-shadow: 0 0 0 2px rgba(59,130,246,.2); }
      .highlight-note-editor-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 10px; }
      .highlight-note-editor button { border: 0; border-radius: 7px; padding: 6px 10px; cursor: pointer; font: inherit; }
      .note-cancel { background: #334155; color: #e2e8f0; }
      .note-save { background: #3b82f6; color: white; }
    `,this.shadowRoot.appendChild(n),this.shadowRoot.appendChild(t),this.positionContainer(t,e,{width:320,height:120})}positionContainer(t,e,n){if(!this.container)return;this.container.style.display="block",this.container.style.visibility="hidden",this.container.style.left="0px",this.container.style.top="0px";const o=t.getBoundingClientRect(),i={width:o.width||n.width,height:o.height||n.height},{left:s,top:c}=ft(e,i,{width:window.innerWidth,height:window.innerHeight});this.container.style.left=`${s}px`,this.container.style.top=`${c}px`,this.container.style.visibility="visible"}showPendingNotePreview(t,e){const n=globalThis.CSS,o=globalThis.Highlight,i=n==null?void 0:n.highlights;if(!i||!o)return;let s=document.getElementById(L);s||(s=document.createElement("style"),s.id=L,s.textContent=`::highlight(${O}) { background-color: ${bt[e]}; }`,(document.head||document.documentElement).appendChild(s)),i.set(O,new o(t.cloneRange()))}clearPendingNotePreview(){var e,n;const t=globalThis.CSS;(e=t==null?void 0:t.highlights)==null||e.delete(O),(n=document.getElementById(L))==null||n.remove()}hide(){this.clearPendingNotePreview(),this.container&&(this.container.style.display="none"),this.currentMode=null,this.currentHighlight=null}showNoteBubble(t,e){var a;if(!this.container||!this.shadowRoot||!e.note||(this.bubbleTimer&&(clearTimeout(this.bubbleTimer),this.bubbleTimer=null),this.currentMode==="existing-highlight"&&((a=this.currentHighlight)==null?void 0:a.id)===e.id))return;const n=document.createElement("div");n.className="note-bubble";const o=J(e.note);n.style.width=`${o}px`;const i=document.createElement("div");i.className="note-text",i.textContent=e.note,n.appendChild(i);const s=document.createElement("button");s.className="note-edit-btn",s.textContent="✏️ 编辑",s.addEventListener("click",l=>{l.stopPropagation(),this.showExistingHighlight(t,e,!0)}),n.appendChild(s),this.shadowRoot.innerHTML="";const c=document.createElement("style");c.textContent=`
      :host { all: initial; }
      .note-bubble {
        background: #1e293b;
        border: 1px solid #334155;
        border-radius: 8px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.4);
        padding: 8px 12px;
        box-sizing: border-box;
        max-width: calc(100vw - 20px);
        position: relative;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
        font-size: 13px;
      }
      .note-text {
        color: #f1f5f9;
        line-height: 1.5;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
        max-height: min(42vh, 320px);
        overflow-y: auto;
        margin-bottom: 8px;
      }
      .note-edit-btn {
        font-size: 12px;
        color: #3b82f6;
        background: none;
        border: none;
        cursor: pointer;
        padding: 2px 0;
        display: block;
        text-align: left;
      }
      .note-edit-btn:hover {
        color: #60a5fa;
      }
    `,this.shadowRoot.appendChild(c),this.shadowRoot.appendChild(n),this.positionContainer(n,t,{width:o,height:90})}hideNoteBubble(){this.bubbleTimer=setTimeout(()=>{this.currentMode===null&&this.hide()},200)}}function yt(r,t,e=Date.now()){return{...r,color:t,updatedAt:e}}function _(r){var o;if(!r||typeof r!="object")return!1;const t=r,e=t.tagName||typeof t.closest=="function"?t:t.parentElement;if(!e)return!1;const n=(o=e.tagName)==null?void 0:o.toUpperCase();return n==="INPUT"||n==="TEXTAREA"||n==="SELECT"||e.isContentEditable?!0:typeof e.closest=="function"&&e.closest('input, textarea, select, [contenteditable="true"], [contenteditable=""]')!==null}function xt(r,t,e){return!e||r.shiftKey||_(r.target)?!1:t==="alt"?r.altKey&&!r.metaKey&&!r.ctrlKey:t==="meta"?r.metaKey&&!r.altKey&&!r.ctrlKey:r.ctrlKey&&!r.altKey&&!r.metaKey}const T=28,Et=24,A=16,W=16,vt=12;function k(r,t,e){return Math.min(Math.max(r,t),Math.max(t,e))}function St(r){return r.reduce((t,e)=>!t||e.right>t.right||e.right===t.right&&e.top<t.top?e:t,void 0)}function Ct(r,t){const e=r.filter(({anchor:a})=>a.bottom>0&&a.top<t.height).sort((a,l)=>a.anchor.top-l.anchor.top);let n=A;const o=e.map(a=>{const l=Math.max(0,a.anchor.bottom-a.anchor.top),g=k(a.anchor.right-T/2,8,t.width-T-8),w=k(a.anchor.top+(l-T)/2,8,t.height-T-8),p=k(t.width-a.cardWidth-Et,12,t.width-a.cardWidth-12),h=k(a.anchor.top,A,t.height-a.cardHeight-W),u=Math.max(h,n);n=u+a.cardHeight+vt;const m=g+T;return{id:a.id,badgeLeft:g,badgeTop:w,cardLeft:p,cardTop:u,connectorLeft:m,connectorTop:w+T/2,connectorWidth:Math.max(0,p-m)}}),i=o[o.length-1],s=i&&e.find(({id:a})=>a===i.id),c=i&&s?i.cardTop+s.cardHeight+W-t.height:0;if(c>0&&o.length>0){const a=Math.max(0,o[0].cardTop-A),l=Math.min(c,a);o.forEach(g=>{g.cardTop-=l})}return o}const Y="web-snapshot-page-note-overlay",Tt={yellow:"#facc15",green:"#4ade80",blue:"#60a5fa",red:"#fb4b55"};function Nt(r){const e=r.split(/\r?\n/).reduce((n,o)=>n+Math.max(1,Math.ceil(o.length/24)),0);return Math.min(220,Math.max(72,48+e*22))}class Ht{constructor(){var n,o;this.rendered=new Map,this.highlights=[],this.visible=!0,this.contentDirty=!0,this.frameId=null,this.handleViewportChange=()=>this.scheduleLayout(),(n=document.getElementById(Y))==null||n.remove(),this.host=document.createElement("div"),this.host.id=Y,this.host.setAttribute("aria-hidden","true"),this.host.style.position="fixed",this.host.style.inset="0",this.host.style.zIndex="2147483644",this.host.style.pointerEvents="none";const t=this.host.attachShadow({mode:"open"}),e=document.createElement("style");e.textContent=`
      :host {
        --ws-note-bg: rgba(15, 35, 65, .96);
        --ws-note-border: rgba(71, 85, 105, .78);
        --ws-note-text: #f8fafc;
        --ws-note-accent: #fb4b55;
        --ws-note-shadow: 0 14px 34px rgba(15, 23, 42, .28), 0 3px 10px rgba(15, 23, 42, .18);
        all: initial;
      }
      .layer {
        position: fixed;
        inset: 0;
        overflow: hidden;
        pointer-events: none;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", sans-serif;
      }
      .status {
        position: absolute;
        top: 18px;
        right: 24px;
        padding: 7px 13px;
        border: 1px solid rgba(148, 163, 184, .42);
        border-radius: 999px;
        background: rgba(255, 255, 255, .9);
        color: #2563eb;
        box-shadow: 0 4px 14px rgba(15, 23, 42, .08);
        font-size: 13px;
        line-height: 1;
        backdrop-filter: blur(8px);
      }
      .badge {
        position: absolute;
        box-sizing: border-box;
        width: 28px;
        height: 28px;
        display: grid;
        place-items: center;
        border: 2px solid var(--ws-note-accent);
        border-radius: 50%;
        background: #0f294c;
        color: white;
        box-shadow: 0 3px 10px rgba(15, 23, 42, .3);
      }
      .badge::before { content: "▤"; font-size: 13px; line-height: 1; }
      .connector {
        position: absolute;
        height: 1px;
        background: var(--ws-note-accent);
        transform: translateY(-.5px);
        transform-origin: left center;
      }
      .card {
        position: absolute;
        box-sizing: border-box;
        min-width: 260px;
        max-width: min(400px, calc(100vw - 24px));
        padding: 16px 18px;
        border: 1px solid var(--ws-note-border);
        border-radius: 12px;
        background: var(--ws-note-bg);
        color: var(--ws-note-text);
        box-shadow: var(--ws-note-shadow);
        font-size: 14px;
        line-height: 1.55;
        backdrop-filter: blur(12px);
      }
      .card-row { display: flex; align-items: flex-start; gap: 12px; }
      .card-dot {
        flex: 0 0 auto;
        width: 18px;
        height: 18px;
        margin-top: 2px;
        border-radius: 4px;
        background: var(--ws-note-accent);
        box-shadow: 0 0 0 1px rgba(255,255,255,.08) inset;
      }
      .card-copy { min-width: 0; max-height: min(42vh, 320px); overflow: auto; }
      .card-label { margin-right: 8px; color: #e2e8f0; font-weight: 650; }
      .card-text { color: #f8fafc; white-space: pre-wrap; overflow-wrap: anywhere; }
    `,this.layer=document.createElement("div"),this.layer.className="layer",this.status=document.createElement("div"),this.status.className="status",this.status.textContent="本页备注：显示 · 已按 URL 记住",t.append(e,this.layer),(document.documentElement||document.body).appendChild(this.host),window.addEventListener("scroll",this.handleViewportChange,!0),window.addEventListener("resize",this.handleViewportChange),this.resizeObserver=typeof ResizeObserver=="function"?new ResizeObserver(this.handleViewportChange):null,document.documentElement&&((o=this.resizeObserver)==null||o.observe(document.documentElement))}setVisible(t){this.visible!==t&&(this.visible=t,this.scheduleLayout())}getVisible(){return this.visible}setHighlights(t){this.highlights=t,this.contentDirty=!0,this.scheduleLayout()}destroy(){var t;window.removeEventListener("scroll",this.handleViewportChange,!0),window.removeEventListener("resize",this.handleViewportChange),(t=this.resizeObserver)==null||t.disconnect(),this.frameId!==null&&window.cancelAnimationFrame(this.frameId),this.frameId=null,this.rendered.clear(),this.host.remove()}scheduleLayout(){this.frameId===null&&(this.frameId=window.requestAnimationFrame(()=>{this.frameId=null,this.render()}))}rebuildContent(){this.layer.replaceChildren(this.status),this.rendered.clear();for(const t of this.highlights.filter(e=>{var n;return(n=e.note)==null?void 0:n.trim()})){const e=Tt[t.color],n=document.createElement("div");n.className="badge",n.style.setProperty("--ws-note-accent",e);const o=document.createElement("div");o.className="connector",o.style.setProperty("--ws-note-accent",e);const i=document.createElement("div");i.className="card",i.style.setProperty("--ws-note-accent",e);const s=J(t.note||"");i.style.width=`${s}px`;const c=document.createElement("div");c.className="card-row";const a=document.createElement("span");a.className="card-dot";const l=document.createElement("div");l.className="card-copy";const g=document.createElement("span");g.className="card-label",g.textContent="〔注〕";const w=document.createElement("span");w.className="card-text",w.textContent=t.note||"",l.append(g,w),c.append(a,l),i.appendChild(c),this.layer.append(o,n,i);const p=i.getBoundingClientRect().height||Nt(t.note||"");this.rendered.set(t.id,{highlight:t,badge:n,card:i,connector:o,cardWidth:s,cardHeight:p})}this.contentDirty=!1}render(){this.contentDirty&&this.rebuildContent(),this.host.style.display="block",this.status.style.display=this.visible&&this.rendered.size>0?"block":"none";const t=new Map;document.querySelectorAll("mark[data-hl-id]").forEach(n=>{n.dataset.hlId&&t.set(n.dataset.hlId,n)});const e=[];this.rendered.forEach((n,o)=>{n.badge.style.display="none",n.card.style.display="none",n.connector.style.display="none";const i=t.get(o);if(!i)return;const s=Array.from(i.getClientRects()).filter(l=>l.width>0||l.height>0).map(l=>({left:l.left,top:l.top,right:l.right,bottom:l.bottom})),c=i.getBoundingClientRect(),a=St(s)||{left:c.left,top:c.top,right:c.right,bottom:c.bottom};a.right===a.left&&a.bottom===a.top||e.push({id:o,anchor:a,cardWidth:n.cardWidth,cardHeight:n.cardHeight})}),Ct(e,{width:window.innerWidth,height:window.innerHeight}).forEach(n=>{const o=this.rendered.get(n.id);o&&(o.badge.style.left=`${n.badgeLeft}px`,o.badge.style.top=`${n.badgeTop}px`,o.badge.style.display="grid",o.card.style.left=`${n.cardLeft}px`,o.card.style.top=`${n.cardTop}px`,o.card.style.display=this.visible?"block":"none",o.connector.style.left=`${n.connectorLeft}px`,o.connector.style.top=`${n.connectorTop}px`,o.connector.style.width=`${n.connectorWidth}px`,o.connector.style.display=this.visible&&n.connectorWidth>0?"block":"none")})}}const kt="web-snapshot:highlights:";class It{constructor(t,e=D,n=$){this.highlights=new Map,this.initialized=!1,this.instanceId=U(),this.handleMouseUp=o=>this.onMouseUp(o),this.handleMouseDown=o=>this.onMouseDown(o),this.handleMouseOver=o=>this.onMouseOver(o),this.handleMouseOut=o=>this.onMouseOut(o),this.textAnchorSystem=t,document.documentElement.dataset.webSnapshotHighlighterOwner=this.instanceId,this.toolbar=new wt(this),this.noteOverlay=new Ht,this.currentPageUrl=window.location.href,this.shortcutSettings=e,this.highlightSettings=n,this.syncDebounced=at(()=>this.syncToStorage(),2e3),this.setupListeners(),this.initialized=!0}setupListeners(){document.addEventListener("mouseup",this.handleMouseUp,!0),document.addEventListener("mousedown",this.handleMouseDown),document.addEventListener("mouseover",this.handleMouseOver),document.addEventListener("mouseout",this.handleMouseOut)}destroy(){document.removeEventListener("mouseup",this.handleMouseUp,!0),document.removeEventListener("mousedown",this.handleMouseDown),document.removeEventListener("mouseover",this.handleMouseOver),document.removeEventListener("mouseout",this.handleMouseOut),this.toolbar.destroy(),this.noteOverlay.destroy(),this.isActiveInstance()&&delete document.documentElement.dataset.webSnapshotHighlighterOwner,this.initialized=!1}onMouseUp(t){var n,o;if(!(!this.isActiveInstance()||this.toolbar.isToolbarEvent(t)||(o=(n=t.target)==null?void 0:n.closest)!=null&&o.call(n,"mark[data-hl-id]"))){if(!xt(t,this.shortcutSettings.selectionModifier,this.shortcutSettings.optionSelectionEnabled)){this.toolbar.hide();return}if(!this.hasCurrentSelection()){this.toolbar.hide();return}t.stopImmediatePropagation(),this.showToolbarForCurrentSelection({clientX:t.clientX,clientY:t.clientY})}}isActiveInstance(){return document.documentElement.dataset.webSnapshotHighlighterOwner===this.instanceId}hasCurrentSelection(){const t=window.getSelection();return!!(t&&!t.isCollapsed&&t.toString().trim().length>0)}showToolbarForCurrentSelection(t){var a,l;const e=window.getSelection();if(!e||e.isCollapsed||e.toString().trim().length===0)return this.toolbar.hide(),!1;const n=((a=e.anchorNode)==null?void 0:a.parentElement)??e.anchorNode,o=((l=e.focusNode)==null?void 0:l.parentElement)??e.focusNode;if(_(n)||_(o))return this.toolbar.hide(),!1;const i=e.getRangeAt(0).cloneRange(),s=i.getBoundingClientRect();if(s.width===0&&s.height===0)return!1;const c=t??s;return this.toolbar.showNewSelection(c,i),!0}updateShortcutSettings(t){this.shortcutSettings=t}updateHighlightSettings(t){this.highlightSettings=t}getDefaultColor(){return this.highlightSettings.defaultColor}setPageNotesVisible(t){this.noteOverlay.setVisible(t)}getPageNotesVisible(){return this.noteOverlay.getVisible()}onMouseDown(t){var n,o;if(!this.isActiveInstance())return;const e=(o=(n=t.target)==null?void 0:n.closest)==null?void 0:o.call(n,"mark[data-hl-id]");if(e!=null&&e.dataset.hlId){const i=this.highlights.get(e.dataset.hlId);i&&(this.toolbar.showExistingHighlight({clientX:t.clientX,clientY:t.clientY},i),t.preventDefault())}}onMouseOver(t){if(!this.isActiveInstance())return;const e=t.target;if(e.tagName==="MARK"&&e.dataset.hlId){const n=this.highlights.get(e.dataset.hlId);n!=null&&n.note&&this.toolbar.showNoteBubble({clientX:t.clientX,clientY:t.clientY},n)}}onMouseOut(t){if(!this.isActiveInstance())return;const e=t.target;e.tagName==="MARK"&&e.dataset.hlId&&this.toolbar.hideNoteBubble()}createHighlight(t,e,n){const o=t.toString();if(!o.trim())return null;const i=this.textAnchorSystem.createFromRange(t),s=U(),c={id:s,pageUrl:this.currentPageUrl,color:e,text:o,note:n,anchor:i,createdAt:Date.now(),updatedAt:Date.now(),status:"valid"};return this.applyMarkTag(t,c),this.highlights.set(s,c),this.refreshNoteOverlay(),this.saveToStorage(),this.syncDebounced(),c}applyMarkTag(t,e){var o;const n=document.createElement("mark");n.dataset.hlId=e.id,n.dataset.hlColor=e.color,(o=e.note)!=null&&o.trim()&&n.setAttribute("data-hl-has-note","true"),n.style.backgroundColor=this.getColorValue(e.color),n.style.borderRadius="2px",n.style.padding="0 2px",n.style.cursor="pointer";try{t.surroundContents(n)}catch{const i=t.extractContents();n.appendChild(i),t.insertNode(n)}}deleteHighlight(t){if(!this.highlights.get(t))return;document.querySelectorAll(`mark[data-hl-id="${t}"]`).forEach(o=>{const i=o.parentNode;if(i){for(;o.firstChild;)i.insertBefore(o.firstChild,o);i.removeChild(o),i.normalize()}}),this.highlights.delete(t),this.refreshNoteOverlay(),this.saveToStorage(),this.syncDebounced(),this.toolbar.hide()}updateNote(t,e){const n=this.highlights.get(t);n&&(n.note=e,n.updatedAt=Date.now(),document.querySelectorAll(`mark[data-hl-id="${t}"]`).forEach(o=>{e.trim()?o.setAttribute("data-hl-has-note","true"):o.removeAttribute("data-hl-has-note")}),this.refreshNoteOverlay(),this.saveToStorage(),this.syncDebounced())}updateColor(t,e){const n=this.highlights.get(t);if(!n)return null;const o=yt(n,e);return this.highlights.set(t,o),document.querySelectorAll(`mark[data-hl-id="${t}"]`).forEach(i=>{i.dataset.hlColor=e,i.style.backgroundColor=this.getColorValue(e)}),this.refreshNoteOverlay(),this.saveToStorage(),this.syncDebounced(),o}restoreHighlights(t){for(const e of t){if(e.status==="invalid")continue;if(document.querySelector(`mark[data-hl-id="${e.id}"]`)){document.querySelectorAll(`mark[data-hl-id="${e.id}"]`).forEach(o=>{var i;(i=e.note)!=null&&i.trim()?o.setAttribute("data-hl-has-note","true"):o.removeAttribute("data-hl-has-note")}),this.highlights.set(e.id,e);continue}const n=this.textAnchorSystem.restoreToRange(e.anchor);n?(this.applyMarkTag(n,e),this.highlights.set(e.id,e)):(e.status="invalid",this.highlights.set(e.id,e))}this.refreshNoteOverlay()}getHighlights(){return Array.from(this.highlights.values())}refreshNoteOverlay(){this.noteOverlay.setHighlights(this.getHighlights())}async saveToStorage(){try{const t=await lt(this.currentPageUrl),e=`${kt}${t}`,n=Array.from(this.highlights.values());await chrome.storage.local.set({[e]:n})}catch(t){console.error("Failed to save highlights:",t)}}async syncToStorage(){await this.saveToStorage(),chrome.runtime.sendMessage({type:"SYNC_HIGHLIGHTS"}).catch(()=>{})}getColorValue(t){return{yellow:"rgba(254, 240, 138, 0.6)",green:"rgba(134, 239, 172, 0.5)",blue:"rgba(147, 197, 253, 0.5)",red:"rgba(252, 165, 165, 0.5)"}[t]}}class Pt{createFromRange(t){const e=this.getXPath(t.startContainer),n=this.getXPath(t.endContainer),o=t.toString();return{startXPath:e,startOffset:t.startOffset,endXPath:n,endOffset:t.endOffset,textContent:o}}restoreToRange(t){try{const e=this.resolveXPath(t.startXPath),n=this.resolveXPath(t.endXPath);if(!e||!n)return this.findTextRange(t.textContent);const o=document.createRange();return o.setStart(e,t.startOffset),o.setEnd(n,t.endOffset),o.toString()!==t.textContent?this.findTextRange(t.textContent):o}catch{return this.findTextRange(t.textContent)}}findTextRange(t){if(!t)return null;const e=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT),n=[];let o="",i;for(;i=e.nextNode();)n.push(i),o+=i.textContent||"";const s=o.indexOf(t);if(s===-1)return null;const c=s+t.length;let a=0,l=null,g=null,w=0,p=0;for(const u of n){const m=(u.textContent||"").length;if(!l&&s>=a&&s<a+m&&(l=u,w=s-a),c>=a&&c<=a+m){g=u,p=c-a;break}a+=m}if(!l||!g)return null;const h=document.createRange();return h.setStart(l,w),h.setEnd(g,p),h}getXPath(t){if(t.nodeType===Node.TEXT_NODE){const e=t.parentNode;if(!e)return"";const o=Array.from(e.childNodes).filter(s=>s.nodeType===Node.TEXT_NODE).indexOf(t);return`${this.getElementXPath(e)}/text()[${o+1}]`}return this.getElementXPath(t)}getElementXPath(t){if(t.id)return`//*[@id="${t.id}"]`;const e=[];let n=t;for(;n&&n!==document.body&&n!==document.documentElement;){let o=1;const i=n.parentElement;i&&(o=Array.from(i.children).filter(c=>c.tagName===n.tagName).indexOf(n)+1),e.unshift(`${n.tagName.toLowerCase()}[${o}]`),n=n.parentElement}return n===document.body?e.unshift("body[1]"):n===document.documentElement&&e.unshift("html[1]"),"/"+e.join("/")}resolveXPath(t){try{return document.evaluate(t,document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue}catch{return null}}}const Mt={yellow:"rgba(254, 240, 138, 0.6)",green:"rgba(134, 239, 172, 0.5)",blue:"rgba(147, 197, 253, 0.5)",red:"rgba(252, 165, 165, 0.5)"};function Ot(r,t){var i;const e=new Map(t.map(s=>[s.id,s])),n=Array.from(r.querySelectorAll("mark[data-hl-id]"));let o=0;for(const s of n){const c=s.dataset.hlId,a=c?e.get(c):void 0;if(!a)continue;s.dataset.webSnapshotHighlight="true",s.dataset.webSnapshotColor=a.color,s.style.backgroundColor=Mt[a.color];const l=(i=a.note)==null?void 0:i.trim();l?(s.dataset.webSnapshotNote=l,s.title=l):(delete s.dataset.webSnapshotNote,s.title=""),o++}return o}function Lt(r){var n;const t=Array.from(r.querySelectorAll("mark[data-web-snapshot-note]"));let e=0;for(const o of t){const i=(n=o.dataset.webSnapshotNote)==null?void 0:n.trim(),s=o.parentNode,c=o.ownerDocument;if(!i||!s||!c)continue;const a=c.createElement("span");a.className="web-snapshot-note",a.setAttribute("role","note");const l=c.createElement("strong");l.textContent="〔注〕",a.append(l,c.createTextNode(` ${i}`)),s.insertBefore(a,o),e++}return e}function Q(r){return`{{WEBSAVE_NOTE:${encodeURIComponent(r)}}}`}function At(r,t){const e=` ==${r.trim()}== `;return t?`${Q(t)}${e}`:e}function _t(r,t){var n;let e=r;for(const o of t){const i=(n=o.note)==null?void 0:n.trim();if(!i)continue;const s=Q(o.id),c=e.indexOf(s);if(c===-1)continue;let a=e.slice(0,c),l=e.slice(c+s.length);a.endsWith(" ")&&l.startsWith(" ")&&(l=l.slice(1)),l=l.replace(/^(==[^\n]*?==) {2,}/,"$1 ");const g=a.lastIndexOf(`
`)+1;a=`${a.slice(0,g)}${ht(i)}
${a.slice(g)}`,e=a+l}return e}function Rt(r,t){const e=new Map(t.map(n=>[n.id,n]));r.addRule("web-snapshot-highlight",{filter:n=>{var o;return n.nodeName==="MARK"&&!!((o=n.getAttribute)!=null&&o.call(n,"data-hl-id"))},replacement:(n,o)=>{var s;const i=e.get(o.getAttribute("data-hl-id"));return At(n,(s=i==null?void 0:i.note)!=null&&s.trim()?i.id:void 0)}})}function Dt(r,t,e){return e?[...t]:ct(r,t)}const tt=window,S=tt.__webSnapshot;var q;try{(q=S==null?void 0:S.destroy)==null||q.call(S)}catch{}var K,I,j;try{(j=(I=(K=S==null?void 0:S.highlighter)==null?void 0:K.call(S))==null?void 0:I.destroy)==null||j.call(I)}catch{}let f=null,R=null,B=!1,P=!0;async function et(r="markdown"){const{Readability:t}=await z(async()=>{const{Readability:u}=await import("./index-Bvl9CaDy.js").then(m=>m.i);return{Readability:u}},[],import.meta.url),e=(await z(async()=>{const{default:u}=await import("./turndown.browser.es-kLzRgxYD.js");return{default:u}},[],import.meta.url)).default,n=await nt(),o=(f==null?void 0:f.getHighlights())||[],i=Dt(n,o,B),s=document.cloneNode(!0),a=new t(s).parse();if(!a)return{html:"",format:r,title:document.title,url:window.location.href,author:null,publishDate:null,images:[],highlights:i};const l=document.createElement("div");l.innerHTML=a.content,Ot(l,i);const g=l.innerHTML,w=l.querySelectorAll("img"),p=[];w.forEach(u=>{u.src&&p.push(u.src)});let h;if(r==="html"){const u=l.cloneNode(!0);Lt(u);const m=u.innerHTML;h=`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>`+(a.title||document.title)+`</title>
<style>
  body{max-width:780px;margin:0 auto;padding:2rem 1.5rem;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC",sans-serif;font-size:16px;line-height:1.8;color:#1a1a1a;background:#fff}
  img{max-width:100%;height:auto}
  pre{background:#f5f5f5;padding:1rem;border-radius:6px;overflow-x:auto;font-size:14px}
  code{background:#f0f0f0;padding:2px 6px;border-radius:3px;font-size:14px}
  pre code{background:none;padding:0}
  blockquote{border-left:3px solid #3b82f6;margin:0;padding:.5rem 1rem;color:#555}
  a{color:#3b82f6}
  mark[data-web-snapshot-highlight="true"]{border-radius:2px;padding:0 2px}
  .web-snapshot-note{display:block;margin:.75rem 0 .5rem;padding:.55rem .75rem;border-left:3px solid #3b82f6;border-radius:0 6px 6px 0;background:#eff6ff;color:#334155;line-height:1.6;white-space:pre-wrap}
  mark[data-web-snapshot-note]{position:relative;cursor:help}
  mark[data-web-snapshot-note]:hover::after{content:attr(data-web-snapshot-note);position:absolute;left:0;bottom:calc(100% + 8px);z-index:10;min-width:180px;max-width:320px;padding:8px 10px;border-radius:8px;background:#0f172a;color:#e2e8f0;box-shadow:0 8px 24px rgba(15,23,42,.28);font-size:13px;line-height:1.5;white-space:normal}
  .src-link{margin-top:2rem;padding-top:1rem;border-top:1px solid #e5e5e5;font-size:14px;color:#888}
</style>
</head>
<body>
`+m+`
<p class="src-link">原文：<a href="`+window.location.href+'">'+(a.title||document.title)+`</a></p>
</body>
</html>`}else{const u=new e({headingStyle:"atx",codeBlockStyle:"fenced",emDelimiter:"*"});u.addRule("img",{filter:"img",replacement:(m,y)=>{const b=y.src;return p.includes(b)||p.push(b),"!["+(y.alt||"")+"]("+b+")"}}),Rt(u,i),h=_t(u.turndown(g),i)}return{html:h,format:r,title:a.title||document.title,url:window.location.href,author:a.byline,publishDate:a.publishedTime,images:p,highlights:i}}async function nt(){try{const r=await chrome.runtime.sendMessage({type:"LOAD_HIGHLIGHTS",payload:{pageUrl:window.location.href}});return Array.isArray(r)?r:[]}catch{return[]}}async function $t(){try{const r=await chrome.runtime.sendMessage({type:"LOAD_PAGE_NOTE_VISIBILITY",payload:{pageUrl:window.location.href}});if((r==null?void 0:r.pageUrl)===window.location.href&&typeof r.visible=="boolean"&&Number.isFinite(r.updatedAt))return r}catch{}return ut(window.location.href)}async function ot(){const r=await chrome.storage.local.get([C.SHORTCUT_SETTINGS,C.HIGHLIGHT_SETTINGS]);if(!P)return;const t={...D,...r[C.SHORTCUT_SETTINGS]},e={...$,...r[C.HIGHLIGHT_SETTINGS]};R=new Pt;const n=new It(R,t,e);f=n;const[o,i]=await Promise.all([nt(),$t()]);if(!P){n.destroy(),f===n&&(f=null);return}o.length>0&&n.restoreHighlights(o),n.setPageNotesVisible(i.visible),B=!0}const it=(r,t,e)=>{var n,o;switch(r.type){case"EXTRACT_CONTENT":{const i=((n=r.payload)==null?void 0:n.format)||"markdown";return dt(et(i),e),!0}case"SHOW_SELECTION_TOOLBAR":return e({shown:(f==null?void 0:f.showToolbarForCurrentSelection())??!1}),!1;case"APPLY_PAGE_NOTE_VISIBILITY":{const i=(o=r.payload)==null?void 0:o.visible;if(typeof i!="boolean")return e({applied:!1}),!1;const s=(f==null?void 0:f.getPageNotesVisible())??!0;return f==null||f.setPageNotesVisible(i),chrome.runtime.sendMessage({type:"SAVE_PAGE_NOTE_VISIBILITY",payload:{pageUrl:window.location.href,visible:i}}).then(c=>{if(c!=null&&c.error)throw new Error(c.error);e({applied:!0,visible:i})}).catch(()=>{f==null||f.setPageNotesVisible(s),e({applied:!1,visible:s})}),!0}default:return!1}};chrome.runtime.onMessage.addListener(it);const st=(r,t)=>{if(t!=="local")return;const e=r[C.SHORTCUT_SETTINGS];if(e){const o=e.newValue;f==null||f.updateShortcutSettings({...D,...o})}const n=r[C.HIGHLIGHT_SETTINGS];if(n){const o=n.newValue;f==null||f.updateHighlightSettings({...$,...o})}for(const[o,i]of Object.entries(r)){if(!o.startsWith(C.PAGE_NOTE_VISIBILITY_PREFIX))continue;const s=i.newValue;(s==null?void 0:s.pageUrl)===window.location.href&&typeof s.visible=="boolean"&&(f==null||f.setPageNotesVisible(s.visible))}};chrome.storage.onChanged.addListener(st);const rt=()=>{ot()};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",rt):ot();function Bt(){if(P){P=!1,document.removeEventListener("DOMContentLoaded",rt),f==null||f.destroy(),f=null,R=null,B=!1;try{chrome.runtime.onMessage.removeListener(it),chrome.storage.onChanged.removeListener(st)}catch{}}}tt.__webSnapshot={extract:et,highlighter:()=>f,destroy:Bt};
